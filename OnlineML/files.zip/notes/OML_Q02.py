import numpy as np

def get_samples():
	M = np.array([[0.3, 0.7],[0.6, 0.4]])
	p = np.array([0.4, 0.6])
	B = np.array([[0.2, 0.3, 0.4, 0.1],[0.4, 0.1, 0.2, 0.3]])
	v = np.array([4, 1, 3]) - 1
	x = np.array([1, 2, 1]) - 1
	return M, p, B, v, x

def joint_prob(M, p, B, v, x):
	result = 0
	T = np.size(v)
	for t in range(T):
		if t == 0:
			result = p[x[t]]*B[x[t], v[t]]
		else:
			result *= M[x[t-1], x[t]]*B[x[t], v[t]]
	return result

M, p, B, v, x = get_samples()

print("===== Q.1(a) =====")
print("Answer: ", p[x[0]]*B[x[0], v[0]]*M[x[0], x[1]]*B[x[1], v[1]]*M[x[1], x[2]]*B[x[2], v[2]])
print("Answer: ", joint_prob(M, p, B, v, x))

def alpha_dynamic(M,p,B,v):
	# ALPHA DYNAMIC calculate alpha
	result = []
	T = np.size(v)
	for t in range(T):
		if t == 0:
			result.append(B[:, int(v[t])]*p)
		else:
			result.append(np.dot(M.T, result[-1])*B[:, int(v[t])])
	return np.array(result).T

print("===== Q.1(b) =====")
print("Answer: \n", alpha_dynamic(M, p, B, v))


def beta_dynamic(M, p, B, v):
	# BETA DYNAMIC(M,p,B,v) calculates the matrix of betas for
	# the hmm with transition matrix M, emission matrix B, and
	# initial probabilities p, given the observations v
	result = []
	T = np.size(v)
	for t in range(T-1, -1, -1):
		if t == T-1:
			result.insert(0, np.ones(np.size(p)))
		else:
			result.insert(0, np.dot( M, B[:, int(v[t+1])]*result[0] ))
	return np.array(result).T

print("===== Q.1(f) =====")
print(beta_dynamic(M, p, B, v))