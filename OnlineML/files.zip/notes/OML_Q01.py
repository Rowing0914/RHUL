import numpy as np
import matplotlib.pyplot as plt
import scipy.stats as st
import seaborn as sns


print("===== Q.2 =====")
M = np.array([[0.9, 0.075, 0.025], [0.15, 0.8, 0.05], [0.25, 0.25, 0.5]])
init_p = np.array([0.4, 0.4, 0.2])
print("Answer for (a): ", M)
print("Answer for (b): ", 0.4*0.9*0.025*0.25*0.15)
print("Answer for (c): M^2\n", M @ M)
print("Answer for (c): M^3\n", M @ M @ M)
print("Answer for (d): ", init_p @ M @ M @ M)
print("Answer for (e): repeat the process below till it converges....")
print(init_p @ M @ M @ M @ M @ M @ M @ M @ M @ M @ M @ M @ M @ M @ M)
print(init_p @ M @ M @ M @ M @ M @ M @ M @ M @ M @ M @ M @ M @ M @ M @ M @ M @ M @ M @ M @ M)


print("\n===== Q.3 =====")
M = np.array([[3, 3, 1], [2, 0, 1], [1, 1, 1]])
print("Answer: \n", M/np.sum(M, axis=1).reshape((3,1)))


print("\n===== Q.4 =====")
M = np.array([[0, 1, 1], [0, 0, 1], [1, 0, 0]])
M = M/np.sum(M, axis=1).reshape((3,1))
# print(M)
dumping_factor = 0.85
M = (1 - dumping_factor)*np.ones((3,3))/3 + dumping_factor * M
# print(M)
w, v = np.linalg.eig(M.T)
print( "Answer: ", np.round((v[:,0]/np.sum(v[:,0])).real, 2) )


print("\n===== Q.7 =====")

def F(x):
    return 2*np.exp(-2*x)

def inv_F(u):
    return -(np.log(1 - u))/2

size = 10000
U = np.random.uniform(0, 1, size)
X = inv_F(U)
seq = np.linspace(0, 3, 100)

plt.hist(X, 50, density=True, facecolor='g', alpha=0.75, label="inv_F(U)")
plt.plot(seq, F(seq), label="F(x)")
plt.legend()
plt.show()


print("\n===== Q.10 =====")
# check this great post for more detail
# https://wiseodd.github.io/techblog/2015/10/17/metropolis-hastings/

mus = np.array([5, 5])
sigmas = np.array([[1, .9], [.9, 1]])


def circle(x, y):
    return (x-1)**2 + (y-2)**2 - 3**2


def pgauss(x, y):
    return st.multivariate_normal.pdf([x, y], mean=mus, cov=sigmas)


def metropolis_hastings(p, iter=1000):
    x, y = 0., 0.
    samples = np.zeros((iter, 2))

    for i in range(iter):
        x_star, y_star = np.array([x, y]) + np.random.normal(size=2)
        if np.random.rand() < p(x_star, y_star) / p(x, y):
            x, y = x_star, y_star
        samples[i] = np.array([x, y])

    return samples


samples = metropolis_hastings(circle, iter=10000)
sns.jointplot(samples[:, 0], samples[:, 1])
plt.show()

samples = metropolis_hastings(pgauss, iter=10000)
sns.jointplot(samples[:, 0], samples[:, 1])
plt.show()
