import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

def AA_Brier(expertsPredictions,outcomes):
  eta = 2.0
  weights = np.ones(expertsPredictions.shape[1])/float(expertsPredictions.shape[1])
  predictions = list()
  for preds, outcome in zip(expertsPredictions, outcomes):
    gamma = -(1/eta) * np.log(np.dot(weights, np.exp(-eta*np.square(np.array( [preds, preds-1] ))).T))
    error = -eta*np.square(preds - outcome)
    weights = error / np.sum(error)
    predictions.append( 1/2 - (gamma[0] - gamma[1])/2 )
  experts_errors = np.cumsum(np.square(expertsPredictions - np.array([outcomes]*expertsPredictions.shape[1]).T), axis=0)
  learner_errors = np.cumsum(np.square(np.array(predictions) - outcomes), axis=0)
  E_ave = np.cumsum(np.square(np.mean(expertsPredictions, axis=1) - outcomes), axis=0)
  return np.array(predictions), experts_errors, learner_errors, E_ave

if __name__ == '__main__':
  df = pd.read_csv('data/tennis1.txt', header=None, sep="\t")
  df.columns = ["game_ID", "p1_win", "p2_win", "pred1_p1", "pred1_p2", 
                "pred2_p1", "pred2_p2", "pred3_p1", "pred3_p2", "pred4_p1", "pred4_p2"]
  df = df[["p1_win", "pred1_p1", "pred2_p1", "pred3_p1", "pred4_p1"]]
  df.columns = ["label", "E1", "E2", "E3", "E4"]
  
  print(df.head()) # check your data

  expertsPredictions, outcomes = df[["E1", "E2", "E3", "E4"]].values, df["label"].values

  predictions, experts_errors, learner_errors, E_ave = AA_Brier(expertsPredictions,outcomes)

  print("Total Loss of Learer: ", learner_errors[-1])

  # ===== visualisation =====
  plt.plot(np.arange(predictions.shape[0]), experts_errors[:,0], label="E1")
  plt.plot(np.arange(predictions.shape[0]), experts_errors[:,1], label="E2")
  plt.plot(np.arange(predictions.shape[0]), experts_errors[:,2], label="E3")
  plt.plot(np.arange(predictions.shape[0]), experts_errors[:,3], label="E4")
  plt.plot(np.arange(predictions.shape[0]), learner_errors, label="EL")
  # Place a legend to the right of this smaller subplot.
  plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)
  plt.title("E1,E2,E3,E4,EL vs time")
  plt.savefig("graphs/first.png", bbox_inches='tight')
  plt.clf()

  plt.plot(np.arange(predictions.shape[0]), experts_errors[:,0] - learner_errors, label="E1 - EL")
  plt.plot(np.arange(predictions.shape[0]), experts_errors[:,1] - learner_errors, label="E2 - EL")
  plt.plot(np.arange(predictions.shape[0]), experts_errors[:,2] - learner_errors, label="E3 - EL")
  plt.plot(np.arange(predictions.shape[0]), experts_errors[:,3] - learner_errors, label="E4 - EL")
  # Place a legend to the right of this smaller subplot.
  plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)
  plt.title("E1-EL,E2-EL,E3-EL,E4-EL")
  plt.savefig("graphs/second.png", bbox_inches='tight')
  plt.clf()

  plt.plot(np.arange(predictions.shape[0]), experts_errors[:,0] - E_ave, label="E1 - E_ave")
  plt.plot(np.arange(predictions.shape[0]), experts_errors[:,1] - E_ave, label="E2 - E_ave")
  plt.plot(np.arange(predictions.shape[0]), experts_errors[:,2] - E_ave, label="E3 - E_ave")
  plt.plot(np.arange(predictions.shape[0]), experts_errors[:,3] - E_ave, label="E4 - E_ave")
  # Place a legend to the right of this smaller subplot.
  plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)
  plt.title("E1-E_ave,E2-E_ave,E3-E_ave,E4-E_ave")
  plt.savefig("graphs/third.png", bbox_inches='tight')
  plt.clf()