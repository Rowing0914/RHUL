import numpy as np
from test_sample import get_samples, assignment_data

def beta_dynamic(M,p,B,v):
  # BETA DYNAMIC(M,p,B,v) calculates the matrix of betas for
  # the hmm with transition matrix M, emission matrix B, and
  # initial probabilities p, given the observations v
  result = []
  T = np.size(v)
  for t in range(T-1, -1, -1):
    if t == T-1:
      result.insert(0, np.ones(np.size(p)))
    else:
      result.insert(0, np.dot( M, B[:, int(v[t+1])-1]*result[0] ))
  return np.array(result).T


if __name__ == '__main__':
  # M, B, p, v = get_samples()
  # print(beta_dynamic(M,p,B,v))

  M, B, p, v = assignment_data()
  print(beta_dynamic(M,p,B,v)[2,17])