import numpy as np

def get_samples():
  M = np.array([[0.8, 0.2],[0.3,0.7]])
  B = np.array([[0.3,0.4,0.1,0.2],[0.2,0.2,0.3,0.3]])
  p = np.array([0.4,0.6])
  v = np.array([4,1,2])
  return M, B, p, v

def assignment_data():
  M = np.loadtxt('data/M.txt')
  B = np.loadtxt('data/B.txt')
  p = np.loadtxt('data/p.txt')
  v = np.loadtxt('data/v.txt')
  return M, B, p, v