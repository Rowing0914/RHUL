import numpy as np
from test_sample import get_samples, assignment_data
from beta_dynamic import beta_dynamic

def alpha_dynamic(M,p,B,v):
  # ALPHA DYNAMIC calculate alpha
  result = []
  T = np.size(v)
  for t in range(T):
    if t == 0:
      result.append(B[:, int(v[t])-1]*p)
    else:
      result.append(np.dot(M.T, result[-1])*B[:, int(v[t])-1])
  return np.array(result).T

def gamma_dynamic(alpha,beta):
  # GAMMA DYNAMIC(alpha,beta) calculate gamma for hmm given
  # alpha and beta
  return alpha*beta/np.sum(alpha*beta, axis=0)

if __name__ == '__main__':
  # M, B, p, v = get_samples()
  # print(gamma_dynamic(alpha_dynamic(M,p,B,v), beta_dynamic(M,p,B,v)))

  M, B, p, v = assignment_data()
  # print(gamma_dynamic(alpha_dynamic(M,p,B,v), beta_dynamic(M,p,B,v)).shape)

  print("Beta: ", beta_dynamic(M,p,B,v)[2,17])
  print("Gamma: ", gamma_dynamic(alpha_dynamic(M,p,B,v), beta_dynamic(M,p,B,v))[4, 9])