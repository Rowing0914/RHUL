function result = Logistic_Regression(X, weights)
% this computes the value following the logistic regression algorithm
[rows, temp] = size(X);
result = [];

for i = 1:rows
    % Since X contains bias col inside, by dot product, we can get the
    % formulae below
    % ?0 + ?'xi 
    % where ?0: bias
    % ? := (?1, . . . , ?p)'
    hypothesis = dot(weights, X(i, :));
    result = [result, 1/(1+exp(-hypothesis))];
end
result = result';
end