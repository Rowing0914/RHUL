function [weights, log_errors, log_weight] = GD(X, y, weights, num_epoch, learning_rate)
% this is the implementation of Gradient Descent

log_errors = [];
log_weight = [];
threshold = 0;
count = 0;

[temp, col1] = size(X);
[temp, col2] = size(weights);

if col1 ~= col2
    print('Your input has wrong dimensions')
else
    for epoch = 1:num_epoch
        y_pred = Logistic_Regression(X, weights);
        MSE = 1/col1*sum((y - y_pred).^2);
        error = y - y_pred;
        d = 2*error.*Derivative_Logistic_Regression(X, weights);
        update_value = ((learning_rate/col1)*d')*X;
        weights = weights + update_value;
        
        % ======= optional task(5) =======
        if (epoch > 1) && (MSE > threshold)
            count = count + 1;
        end
        
        if count == 10
            fprintf('Epoch: %d, your training is done!!\n', epoch);
            break
        end
        
        % update the threshold
        threshold = MSE*0.99;
        
        % update the training history
        log_errors = [log_errors; MSE];
        log_weight = [log_weight; weights];
    end
end
end