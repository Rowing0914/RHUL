function result = Softmax(data)
% this computes the softmax function given data

% To deal with numeric stability issues, we quickly normalise the data
data = data - max(data);
result = exp(data)/sum(exp(data));
end