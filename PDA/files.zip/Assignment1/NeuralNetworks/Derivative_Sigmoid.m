function result = Derivative_Sigmoid(X, weights)
% this is the derivated logistic regression algorithm
result = Logistic_Regression(X, weights).*(1 - Logistic_Regression(X, weights));
end