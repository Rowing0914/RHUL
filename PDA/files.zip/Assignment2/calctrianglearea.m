% marking id: 2290
% WRITE HERE YOUR FUNCTION FOR EXERCISE 5
function result = calctrianglearea(n)
% takes nx2 matrix of real numbers, representing n points in 2D space
% then responds the areas of the triangles whose vertiecs are the sets of 3
% consecutive points in the matrix.
[row, col] = size(n);

reminder = rem(row, 3);
iteration = int8((row-reminder)/3);

if reminder ~= 0
    reminders = n((row-reminder)+1:row, :);
    n = n(1:(row-reminder), :);
end

temp = arrayfun(@(x) [x, x+1, x+2], 1:3:iteration*3, 'un', 0);

length_matrix = arrayfun(@(x) length_calculator(n(temp{x}, :)), 1:length(temp), 'un', 0);
fprintf('RESULT: %d triangle areas have been successfully calculated\n', iteration);
if reminder ~= 0
    fprintf('The data points below have not been used\n');
    disp(reminders);
else
    fprintf('All data points have been used\n');
end
temp = arrayfun(@(x) area_calculator(length_matrix{x}), 1:length(length_matrix), 'un', 0);
result = cell2mat(temp);

end