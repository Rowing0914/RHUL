function print_mytemperature(M)
% print out the input matrix on the console window
disp(M);
end