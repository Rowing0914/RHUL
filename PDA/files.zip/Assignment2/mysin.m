% marking ID: 2290
% WRITE HERE YOUR FUNCTION FOR EXERCISE 3
function mysin(num1, num2)
% this plots the sin function with a different number of points between 0 and 2pi.

choice_colour = menu('Choose a colour', 'red', 'blue', 'green');
choice_style = menu('Choose a style', 'circle', 'star');

step_size1 = (2*pi)/(num1-1);
step_size2 = (2*pi)/(num2-1);

switch choice_colour
    case 1
        if choice_style == 1
            subplot(2,1,1);
            plot(0:step_size1:2*pi, sin(0:step_size1:2*pi), 'r-o');
            title([num2str(num1), ' points']);
            grid on
            subplot(2,1,2);
            plot(0:step_size2:2*pi, sin(0:step_size2:2*pi), 'r-o');
            title([num2str(num2), ' points']);
            grid on
        elseif choice_style == 2
            subplot(2,1,1);
            plot(0:step_size1:2*pi, sin(0:step_size1:2*pi), 'r-*');
            title([num2str(num1), ' points']);
            grid on
            subplot(2,1,2);
            plot(0:step_size2:2*pi, sin(0:step_size2:2*pi), 'r-*');
            title([num2str(num2), ' points']);
            grid on
        end
    case 2
        if choice_style == 1
            subplot(2,1,1);
            plot(0:step_size1:2*pi, sin(0:step_size1:2*pi), 'b-o');
            title([num2str(num1), ' points']);
            grid on
            subplot(2,1,2);
            plot(0:step_size2:2*pi, sin(0:step_size2:2*pi), 'b-o');
            title([num2str(num2), ' points']);
            grid on
        elseif choice_style == 2
            subplot(2,1,1);
            plot(0:step_size1:2*pi, sin(0:step_size1:2*pi), 'b-*');
            title([num2str(num1), ' points']);
            grid on
            subplot(2,1,2);
            plot(0:step_size2:2*pi, sin(0:step_size2:2*pi), 'b-*');
            title([num2str(num2), ' points']);
            grid on
        end
    case 3
        if choice_style == 1
            subplot(2,1,1);
            plot(0:step_size1:2*pi, sin(0:step_size1:2*pi), 'g-o');
            title([num2str(num1), ' points']);
            grid on
            subplot(2,1,2);
            plot(0:step_size2:2*pi, sin(0:step_size2:2*pi), 'g-o');
            title([num2str(num2), ' points']);
            grid on
        elseif choice_style == 2
            subplot(2,1,1);
            plot(0:step_size1:2*pi, sin(0:step_size1:2*pi), 'g-*');
            title([num2str(num1), ' points']);
            grid on
            subplot(2,1,2);
            plot(0:step_size2:2*pi, sin(0:step_size2:2*pi), 'g-*');
            title([num2str(num2), ' points']);
            grid on
        end
    otherwise
        disp('Error!')
end
end