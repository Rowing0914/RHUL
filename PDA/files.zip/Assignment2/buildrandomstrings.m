% marking id: 2290
% WRITE HERE YOUR FUNCTION FOR EXERCISE 4
function result = buildrandomstrings(n)
% this function returns the cell array containing randomly generated
% characters.

ints = randi([97 122],1,int8(abs(n)));
temp = arrayfun(@char, ints);

if n > 0
    result = arrayfun(@(x) temp(1:x), 1:int8(n), 'un', 0);
elseif n < 0
    result = arrayfun(@(x) temp(1:x), int8(abs(n)):-1:1, 'un', 0);
else
    fprintf('give me an integer except 0');
    result = 0;
end