% marking ID: 2290
% WRITE HERE YOUR FUNCTION FOR EXERCISE 2
function result = uniqueword(string)
% this returns a series of 5 unique words by concatenating the persistent
% integer which is controlled by count

persistent count;
if isempty(count)
    % always initialise with 1
    count = 1;
    result = strcat(string, int2str(count));
    count = count+1;
elseif count > 5
    fprintf('You have called the function 5 times. So the persistent value is refreshed.\n')
    result = 0;
else
   result = strcat(string, int2str(count));
   count = count+1;
end
end