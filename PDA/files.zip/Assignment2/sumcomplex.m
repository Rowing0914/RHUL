% marking id: 2290
% WRITE HERE YOUR FUNCTION FOR EXERCISE 8
function result = sumcomplex(R, I, S)
% this will calculate sums of complex numbers and then outputs the
% structure array containing the imagery and real value part

% error handling
if (length(R) ~= length(I)) || (max(S) > length(R))
    fprintf('The length of the input vectors not matching')
    result = 0;
else
    real = sum(R(S));
    img  = sum(I(S));
    result = struct('real', real, 'img', img);
end