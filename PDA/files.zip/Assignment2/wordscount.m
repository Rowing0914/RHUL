% Marking ID: 2290
% WRITE HERE YOUR FUNCTION FOR EXERCISE 9
function result = wordscount(n)
% Loads the text from the RedRidingHood.txt and count the frequency of the
% words in it. Then this outputs the n least/most frequent words.
% Note: Case-Insensitive
filename = 'RedRidingHood.txt';
original_text = lower(fileread(filename));
text = sort(strsplit(original_text));
vocabulary = unique(text);
occurency = {};
test = {};

for i = 1:length(vocabulary)
    count = 0;
    for index = 1:length(text)
        if strcmp(vocabulary(i), text(index))
            count = count + 1;
        end
        occurency{i, 1} = [i, count];
        test{i, 1} = {vocabulary(i), count};
    end
end

occurency = sortrows(cell2mat(occurency), 2);
last_index = length(occurency);
most_freq_n = occurency(last_index-n+1:last_index, :);
least_freq_n = occurency(1:n, :);
most_freq_words = vocabulary(most_freq_n(:,1));
least_freq_words = vocabulary(least_freq_n(:,1));
result = struct('most_frequent', {num2cell(most_freq_n(:,2)), most_freq_words'}, 'least_frequent', {num2cell(least_freq_n(:,2)), least_freq_words'});
end