function result = length_calculator(matrix)
% takes 3x2 matrix, and responds the outcome of the lengths between each
% point

len1 = norm(matrix(1,:) - matrix(2,:));
len2 = norm(matrix(1,:) - matrix(3,:));
len3 = norm(matrix(2,:) - matrix(3,:));

result = [(len1+len2+len3)/3, len1, len2, len3];
end