% marking id: 2290
% WRITE HERE YOUR FUNCTION FOR EXERCISE 6
function result = mytemperature(num1, num2)
% takes two inputs num1, num2, which represent min and max respectively.
% then calculates the corresponding temperatures and responds the combined
% matrix

if num1 < num2
    min = num1;
    max = num2;
elseif num1 > num2
    min = num2;
    max = num1;
else
    min = num2;
    max = num1;
end

if (mod(num1,1)==0) && (mod(num2,1)==0)
    col1 = min:max;
else
    col1 = linspace(min, max, 10);
end

col2 = arrayfun(@(x) (x-32)*(5/9), col1);
M = [col1', col2'];
print_mytemperature(M);
result = M;
end