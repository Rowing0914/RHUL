% markin id:2290
% WRITE HERE YOUR SCRIPT FOR EXERCISE 7
function myevalue1
% this will loop through values of n until the difference between the approximation
% of e and the actual value of built-in value of e is less than 0.0001.

true_value = exp(1);
n = 1;
estimate = 0;

while true_value - estimate > 0.0001
    estimate = myevalue2(n);
    n = n+1;
end
fprintf('Stopped at: %d iteration.\nTrue value: %.4f, Estimatation: %.4f\n', n, true_value, estimate);
end