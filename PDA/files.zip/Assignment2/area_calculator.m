function result = area_calculator(vec)
% takes 1x4 vector, and responds the outcome of the area

s = vec(1);
a = vec(2);
b = vec(3);
c = vec(4);

result = sqrt(s*(s-a)*(s-b)*(s-c));
end