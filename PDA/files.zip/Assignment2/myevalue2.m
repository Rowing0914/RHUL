% marking id: 2290
% WRITE HERE YOUR SCRIPT FOR EXERCISE 7
function result = myevalue2(upper_bound)
% this computes the value for exponential
result = sum(arrayfun(@(x) 1/factorial(x), 0:upper_bound));
end