% Marking ID: 2290
% WRITE HERE YOUR FUNCTION FOR EXERCISE 1
function result = waferstore(part_numbers, quants, costs)
% This function converts the input vectors into struct data types.
% also, prints out the part number and the total cost
% then, returns the generated struct

[row1, col1] = size(part_numbers);
[row2, col2] = size(quants);
[row3, col3] = size(costs);

r1 = row1==row2;
r2 = row1==row3;
r3 = row2==row3;

c1 = col1==col2;
c2 = col1==col3;
c3 = col2==col3;

if (r1==r2==r3) && (c1==c2==c3)
    fprintf('%d %5.2f\n', [part_numbers;quants.*costs]);
    result = struct('partno', num2cell(part_numbers), 'quantity', num2cell(quants), 'costper', num2cell(costs));
else
    fprintf('your input dimension does not match to the interface of this function....');
    result = 0;
end
end