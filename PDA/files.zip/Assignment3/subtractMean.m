% WRITE YOU CODE HERE!!!
% marking id: 2290
function result = subtractMean(X)
% take an input matrix and returns the mu and Xmu, which is the column-wise
% mean of the matrix and the matrix subtracted by mean.

mu = mean(X);
Xmu = X - mu;
result = struct("mu", mu, "Xmu", Xmu);
end