% WRITE YOU CODE HERE!!! 
% marking id: 2290
function result = projectData(Z, eigenvectors, k)
% take input as a matrix, its eigenvectors and an integer k, then returns
% a dataset obtained by projecting the input dataset onto the first k
% eigenvectors

result = Z*eigenvectors(:, 1:k);
end