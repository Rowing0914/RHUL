% WRITE YOU CODE HERE!!!
% marking id: 2290
function plottrigs(varargin)
% this will plot either the sin or the cos in the range from -2pi to 2pi

switch nargin
    case 1
        sin_cos    = varargin{1};
        colour     = "b";
        line_width = 1.0;
        marker     = "o";
    case 2
        sin_cos    = varargin{1};
        colour     = varargin{2};
        line_width = 1.0;
        marker     = "o";
    case 3
        sin_cos    = varargin{1};
        colour     = varargin{2};
        line_width = varargin{3};
        marker     = "o";
    case 4
        sin_cos    = varargin{1};
        colour     = varargin{2};
        line_width = varargin{3};
        marker     = varargin{4};
end

data = -2*pi:0.1:2*pi;
line = strcat("-", colour, marker);

switch sin_cos
    case "sin"
        plot(sin(data), line, "LineWidth", line_width);
        temp = strcat(int2str(nargin), " input arguments");
        title(temp);
        grid on
    case "cos"
        plot(cos(data), line, "LineWidth", line_width);
        temp = strcat(int2str(nargin), " input arguments");
        title(temp);
        grid on
    otherwise
        fprintf("Please make sure that your first argument is either sin or cos!!\n");

end