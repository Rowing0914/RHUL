% marking id: 2290
function result = my_tf(vocabulary, docs)
% take inputs as vocabulary and filenames then returns the occurency of the % words in the given vocabulary

result = zeros(length(vocabulary), length(docs));

for id = 1:length(docs)
    original_text = lower(fileread(docs(id)));
    text = sort(strsplit(original_text));

    for i = 1:length(vocabulary)
        count = 0;
        for index = 1:length(text)
            if strcmp(vocabulary(i), text(index))
                count = count + 1;
            end
            result(i, id) = count;
        end
    end
end
end