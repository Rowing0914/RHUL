% WRITE YOU CODE HERE!!!
% marking id: 2290
function result = myPCA(X)
% take input as a matrix, and returns the two values, which are principle
% components and the set of corresponding eignvalues

% V: eigenvalues which is sorted in ascending order
% D: eigenvectors which is sorted in ascending order
[V, D] = eig(cov(X));

result = struct("U", fliplr(V), "S", flipud(D));

end