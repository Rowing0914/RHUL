% marking id: 2290
% WRITE YOU CODE HERE!!!
function docdistances()
% computes TF-IDF values for the given documents below, then visualise the
% cosine similarities among them.

docs = ["RedRidingHood.txt", "PrincessPea.txt", "Cinderella.txt", "CAFA1.txt", "CAFA2.txt", "CAFA3.txt"];

full_text = [];

for index = 1:length(docs)
    original_text = lower(fileread(docs(index)));
    full_text = strcat(full_text, " ", original_text);
end

text = sort(strsplit(full_text));
vocabulary = unique(text);

TF = my_tf(vocabulary, docs);
IDF = idf(vocabulary, docs);
IDF = [IDF,IDF,IDF,IDF,IDF,IDF];
TF_IDF = TF.*IDF;

base = TF_IDF'*TF_IDF;
normaliser = vecnorm(TF_IDF)'*vecnorm(TF_IDF);

result = base./normaliser;
result = 1 - result;

% visualise data
imagesc(result);
title("Cosine Distance");
colormap(gray);
colorbar;
xticklabels(["RRH", "PPea", "Cinde", "CAFA1", "CAFA2", "CAFA3"]);
yticklabels(["RRH", "PPea", "Cinde", "CAFA1", "CAFA2", "CAFA3"]);

end