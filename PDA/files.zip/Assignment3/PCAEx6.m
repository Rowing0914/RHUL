% WRITE YOU CODE HERE!!!
% marking id: 2290
function PCAEx6()
% this does the pca analysis on the "pcadata.mat" dataset, and display the
% neccessary images

% task 1
load pcadata.mat;

% task 2
figure(1);
scatter(X(:,1), X(:,2));
title("Data Points and their 2 principal components");
xmin = 0;
xmax = 7;
ymin = 2;
ymax = 8;
xlim([xmin, xmax]);
ylim([ymin, ymax]);

% task 3
a = subtractMean(X);

% task 4
b = myPCA(a.Xmu);

% task 5
temp = b.U+[a.mu; a.mu];

x = [temp(1,1), a.mu(1)];
y = [temp(2,1), a.mu(2)];
line(x, y, 'Color', 'green', 'LineWidth', 2);
x = [temp(1,2), a.mu(1)];
y = [temp(2,2), a.mu(2)];
line(x, y, 'Color', 'red', 'LineWidth', 2);

% task 6
Z = projectData(a.Xmu, b.U, 1);

% task 7
disp(Z(1:3, :));

figure(2);
scatter(X(:,1), X(:,2));
title("Data Points and their construction");
xlim([xmin, xmax]);
ylim([ymin, ymax]);
hold on

Xrec = recoverData(Z, b.U, 1, a.mu);
scatter(Xrec(:,1),Xrec(:,2), 'r*');

end