% WRITE YOU CODE HERE!!!
% marking id: 2290
function face_images()
% this does the pca analysis on the "pcafaces.mat" dataset, and display the
% neccessary images

% task 1
load pcafaces.mat;

% task 2
displayData(X(1:100, :));
title("Figure C");

% task 3
a = subtractMean(X);

% task 4
b = myPCA(a.Xmu);
Z = projectData(a.Xmu, b.U, 200);

% task 5
Xrec = recoverData(Z, b.U, 200, a.mu);

% task 6
figure(1);
displayData(X(1:100, :));
title("Original Faces");
figure(2);
displayData(Xrec(1:100, :));
title("Recovered Faces");

end