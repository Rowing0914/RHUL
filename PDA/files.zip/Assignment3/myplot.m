% WRITE YOU CODE HERE!!!
% marking id: 2290
function myplot(x, y)
% this will load the plot_properties.mat file  and will make 
% the 3 corresponding plots as subplots of the same figure

load('plot_properties.mat');

subplot(3,1,1);
line = strcat(plot_properties(1).plotproperties.LineStyle, plot_properties(1).plotproperties.Color);
feval(plot_properties(1).plottype, x, y, line, "LineWidth", plot_properties(1).plotproperties.LineWidth);
grid on

subplot(3,1,2);
feval(plot_properties(2).plottype, x, y, "FaceColor", plot_properties(2).plotproperties.FaceColor, "EdgeColor", plot_properties(2).plotproperties.EdgeColor, "BarWidth", plot_properties(2).plotproperties.BarWidth);
grid on

subplot(3,1,3);
feval(plot_properties(3).plottype, x, y, "FaceColor", plot_properties(3).plotproperties.FaceColor, "EdgeColor", plot_properties(3).plotproperties.EdgeColor, "BarWidth", plot_properties(3).plotproperties.BarWidth);
grid on

end