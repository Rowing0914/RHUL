% WRITE YOU CODE HERE!!!
% marking id: 2290
function myplotarea(filename, n)
% this reads the data from given filename, and plot the area based on the
% input n.

text = fileread(filename);
text = regexprep(text, 'x ', '');
mat = str2num(regexprep(text, ' y ', ','));

if n > length(mat)
    fprintf('ERROR: choose n from 1 to %d\n', length(mat));
else
    area(mat(1:n, 1), mat(1:n, 2));
    xlabel("x");
    ylabel("y");
    title(strcat(num2str(n)," data points"));
end
end