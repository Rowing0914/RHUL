% WRITE YOU CODE HERE!!!
% marking id: 2290
function membersplot(g1, g2)
% this takes two arguments representing the graph types.
% Based on the args, it displays the corresponding graph!

x = 1:4;
y = [22,45,23,33];
labels = {'ME', 'BM', 'CE', 'EE'};

if (strcmp(g1,'bar')) && (strcmp(g2,'bar'))
    graph_type = 1;
elseif (strcmp(g1,'bar')) && (strcmp(g2,'barh'))
    graph_type = 2;
elseif (strcmp(g1,'bar')) && (strcmp(g2,'pie'))
    graph_type = 3;
elseif (strcmp(g1,'barh')) && (strcmp(g2,'bar'))
    graph_type = 4;
elseif (strcmp(g1,'barh')) && (strcmp(g2,'barh'))
    graph_type = 5;
elseif (strcmp(g1,'barh')) && (strcmp(g2,'pie'))
    graph_type = 6;
elseif (strcmp(g1,'pie')) && (strcmp(g2,'bar'))
    graph_type = 7;
elseif (strcmp(g1,'pie')) && (strcmp(g2,'barh'))
    graph_type = 8;
elseif (strcmp(g1,'pie')) && (strcmp(g2,'pie'))
    graph_type = 9;
else
    fprintf('Please choose type of graph from pie,bar,barh');
end
    
switch graph_type
    case 1
        subplot(1,2,1);
        bar(x, y)
        set(gca, 'xticklabel', labels)
        xlabel("Department");
        ylabel("Number of Faculty members");
        grid on
        subplot(1,2,2);
        bar(x, y)
        set(gca, 'xticklabel', labels)
        xlabel("Department");
        ylabel("Number of Faculty members");
        grid on
    case 2
        subplot(1,2,1);
        bar(x, y)
        set(gca, 'xticklabel', labels)
        xlabel("Department");
        ylabel("Number of Faculty members");
        grid on
        subplot(1,2,2);
        barh(x, y)
        xlabel("Number of Faculty members")
        ylabel("Department")
        set(gca, 'yticklabel', labels)
        grid on
    case 3
        subplot(1,2,1);
        bar(x, y)
        set(gca, 'xticklabel', labels)
        xlabel("Department");
        ylabel("Number of Faculty members");
        grid on
        subplot(1,2,2);
        pie(y, labels)
        title("Faculty members by Department")
        grid on
    case 4
        subplot(1,2,1);
        barh(x, y)
        xlabel("Number of Faculty members")
        ylabel("Department")
        set(gca, 'yticklabel', labels)
        grid on
        subplot(1,2,2);
        bar(x, y)
        set(gca, 'xticklabel', labels)
        xlabel("Department");
        ylabel("Number of Faculty members");
        grid on
    case 5
        subplot(1,2,1);
        barh(x, y)
        xlabel("Number of Faculty members")
        ylabel("Department")
        set(gca, 'yticklabel', labels)
        grid on
        subplot(1,2,2);
        barh(x, y)
        xlabel("Number of Faculty members")
        ylabel("Department")
        set(gca, 'yticklabel', labels)
        grid on
    case 6
        subplot(1,2,1);
        barh(x, y)
        xlabel("Number of Faculty members")
        ylabel("Department")
        set(gca, 'yticklabel', labels)
        grid on
        subplot(1,2,2);
        pie(y, labels)
        title("Faculty members by Department")
        grid on
    case 7
        subplot(1,2,1);
        pie(y, labels)
        title("Faculty members by Department")
        grid on
        subplot(1,2,2);
        bar(x, y)
        set(gca, 'xticklabel', labels)
        xlabel("Department");
        ylabel("Number of Faculty members");
        grid on
    case 8
        subplot(1,2,1);
        pie(y, labels)
        title("Faculty members by Department")
        grid on
        subplot(1,2,2);
        barh(x, y)
        xlabel("Number of Faculty members")
        ylabel("Department")
        set(gca, 'yticklabel', labels)
        grid on
    case 8
        subplot(1,2,1);
        pie(y, labels)
        title("Faculty members by Department")
        grid on
        subplot(1,2,2);
        pie(y, labels)
        title("Faculty members by Department")
        grid on
    otherwise
        disp('Error!')
end

end