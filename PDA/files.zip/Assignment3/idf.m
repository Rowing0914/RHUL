% marking id: 2290
function result = idf(vocabulary, docs)
% compute inverse term frequency baed on the given vocabulary and filenames

result = zeros(length(vocabulary), length(docs));

for id = 1:length(docs)
    original_text = lower(fileread(docs(id)));
    text = sort(strsplit(original_text));
    V = unique(text);
    for i = 1:length(vocabulary)
        for index = 1:length(V)
            if strcmp(vocabulary(i), V(index))
                result(i, id) = 1;
                break
            end
        end
    end
end
result = log10(sum(result, 2)./length(docs));
end