import numpy as np
from sklearn.datasets import load_iris

iris = load_iris()

X = np.genfromtxt("ionosphere.txt",delimiter=",")

from sklearn.model_selection import train_test_split
X_train_iris, X_test_iris, y_train_iris, y_test_iris = train_test_split(iris['data'], iris['target'], random_state=0)
# last column of X is the label column, so we can specify it by X[:,-1]
X_train_ionosphere, X_test_ionosphere, y_train_ionosphere, y_test_ionosphere = train_test_split(X, X[:,-1], random_state=0)

class NN:
	def __init__(self, n_neighbors):
		""" initialise step """
		self._n_neighbors = n_neighbors

	def fit(self, features, label):
		""" fit the dataset to the model """
		self._data = np.concatenate((features, label.reshape(len(label), 1)), axis=1)
		self.classes = np.unique(label)
		self._dim_features = features.shape[1]

	def efficient_predict(self, new_data):
		""" Efficient way of Nearest Neighbours """
		# output
		result = []

		for data in new_data:
			# calculate the distance one by one
			for index, row in enumerate(self._data):
				if index == 0:
					# target to compare
					prev_distance = self._dist_calc(data, row[:-1])
				else:
					# store the distance
					distance = self._dist_calc(data, row[:-1])
					# comparison and find out the nearer one
					if distance < prev_distance:
						temp_result = row[-1]
			result.append(temp_result)
		return np.array(result)

	def accurate_predict(self, new_data):
		""" Accurate way of Nearest Neighbours """
		# output
		result = []

		for data in new_data:
			distances = []
			# calculate the distance one by one
			for index, row in enumerate(self._data):
				# calculate the distance
				distance = self._dist_calc(data, row[:-1])
				distances.append([index, distance, row[-1]])

			# sort the list
			distances.sort(key=lambda item: item[1])

			# since the list is sorted, a first item is the nearest one to the sample data
			result.append(distances[0][2])

		return np.array(result)

	def conformal_predict(self, new_data):
		""" this computes the conformity score, 
			then calculates the p-value according to the order in conformity scores
		"""
		afps = []
		preds = []
		p_values = []
		for data in new_data:
			for cls in self.classes:
				self._temp_data = list(data)
				# appending the class to the data to calculate the conformity score with the whole dataset adding the data with all labels respectively
				self._temp_data.append(cls)

				# pushing back the new data to the dataset with certain label
				self._temp_data = np.concatenate((self._data, np.array(self._temp_data).reshape(1,len(self._temp_data))))

				# obtain the index of the new data
				temp_index = len(self._temp_data)

				# calcualte the conformity score for whole dataset
				conformity_scores = list(map(self._conformity_score, self._temp_data))

				# attach the indices to the data
				conformity_scores = [[i,x] for i,x in enumerate(conformity_scores)]

				# sort the list in descending order
				conformity_scores.sort(key=lambda item: item[1], reverse=True)

				# calculate P-value followed by appending
				# in this computation, "i" represents the rank of the sample, so we can just divide it by n+1, which is temp_index in this case
				p_values.append([ [cls, i/(temp_index)] for i,a in enumerate(conformity_scores) if a[0] == (temp_index-1) ][0])

			# sort the list in descending order
			p_values.sort(key=lambda item: item[1], reverse=True)

			# calculate the average false p value
			temp = np.sum([x[1] for x in p_values[1:]])
			afp = temp/(len(self.classes)-1)

			# prepare the return
			preds.append(p_values[0][0])
			p_values = []
			afps.append(afp)
		return float(sum(afps))/float(len(afps)), np.array(preds)

	def _conformity_score(self, new_data):
		""" this computes the conformity score following the formula below
			other_class_diatance / float(same_class_distance
		"""
		# calculate the distance one by one
		distances = [ [index, self._dist_calc(new_data[:-1], row[:-1]), row[-1]] for index, row in enumerate(self._temp_data) ]

		# sort the list in ascending order
		distances.sort(key=lambda item: item[1])

		# remove itself from the list
		distances = distances[1:]

		_class = distances[0][2]
		same_class_distance = distances[0][1]

		for d in distances:
			if int(d[2]) != int(_class):
				# since distances is sorted, we only pick the first(nearest) data from different class, and terminates the loop operation.
				other_class_diatance = d[1]

				if (same_class_distance == 0) or (other_class_diatance == 0):
					return 0
				else:
					return float(other_class_diatance) / float(same_class_distance)

	def _optional_conformity_score(self, new_data):
		""" this computes the conformity score following the formula below
			1 / float(same_class_distance
		"""
		# calculate the distance one by one
		distances = [ [index, self._dist_calc(new_data, row), row[-1]] for index, row in enumerate(self._data)]

		# sort the list
		distances.sort(key=lambda item: item[1])

		# remove itself from the list
		distances = distances[1:]

		_class = distances[0][2]
		same_class_distance = distances[0][1]

		if same_class_distance == 0:
			return 0
		else:
			return 1.0 / float(same_class_distance)

	def _dist_calc(self, A, B):
		""" this computes the distance between two points in Euclidean space """
		return np.sqrt(np.sum(np.square(np.subtract(A,B))))

	def score(self, X_test, y_test):
		""" this computes the accuracy of the model using efficient_predict"""
		y_pred = self.efficient_predict(X_test)
		return np.mean(y_pred == y_test)

	def _score(self, X_test, y_test):
		""" this computes the accuracy of the model using accurate_predict"""
		y_pred = self.accurate_predict(X_test)
		return np.mean(y_pred == y_test)

	def cp_score(self, X_test, y_test):
		""" this computes the accuracy of the model using conformal prediction """
		_, pred = self.conformal_predict(X_test)
		return np.mean(y_test==pred)

nn = NN(n_neighbors=1)
nn.fit(X_train_iris, y_train_iris)
# print(nn.score(X_test_iris, y_test_iris))
print(nn.cp_score(X_test_iris, y_test_iris))
afp, _ = nn.conformal_predict(X_test_iris)
print(afp)
asdf

# nn = NN(n_neighbors=1)
# nn.fit(X_train_ionosphere, y_train_ionosphere)
# print(nn.score(X_test_ionosphere, y_test_ionosphere))
# print(nn.cp_score(X_test_ionosphere, y_test_ionosphere))
# afp, _ = nn.conformal_predict(X_test_ionosphere)
# print(afp)



# test with iris data
from sklearn.neighbors import KNeighborsClassifier

sc_lean_nn = KNeighborsClassifier(n_neighbors=1)
nn         = NN(n_neighbors=1)

for model, model_name in zip([sc_lean_nn, nn], ["sc_lean_nn", "nn"]):
    model.fit(X_train_iris, y_train_iris)
    print("Model: {0}, test error rate: {1}".format(model_name, 1-model.score(X_test_iris, y_test_iris)))
print("Optional Accurate_predict, test error rate: ", 1-nn._score(X_test_iris, y_test_iris))

# test with other dataset
from sklearn.neighbors import KNeighborsClassifier
sc_lean_nn = KNeighborsClassifier(n_neighbors=1)
nn         = NN(n_neighbors=1)

for model, model_name in zip([sc_lean_nn, nn], ["sc_lean_nn", "nn"]):
    model.fit(X_train_ionosphere, y_train_ionosphere)
    print("Model: {0}, test error rate: {1}".format(model_name, 1-model.score(X_test_ionosphere, y_test_ionosphere)))
print("Optional Accurate_predict, test error rate: ", 1-nn._score(X_test_ionosphere, y_test_ionosphere))
