import numpy as np
from sklearn.datasets import load_iris

iris = load_iris()

X = np.genfromtxt("ionosphere.txt",delimiter=",")

from sklearn.model_selection import train_test_split
X_train_iris, X_test_iris, y_train_iris, y_test_iris = train_test_split(iris['data'], iris['target'], random_state=0)
# last column of X is the label column, so we can specify it by X[:,-1]
X_train_ionosphere, X_test_ionosphere, y_train_ionosphere, y_test_ionosphere = train_test_split(X, X[:,-1], random_state=0)

class NN:
	def __init__(self, n_neighbors):
		self._n_neighbors = n_neighbors

	def fit(self, features, label):
		self._data = np.concatenate((features, label.reshape(len(label), 1)), axis=1)
		self.classes = np.unique(label)
		self._dim_features = features.shape[1]

	def predict(self, new_data):
		# output
		result = []

		for data in new_data:
			distances = []
			# calculate the distance one by one
			for index, row in enumerate(self._data):
				# calculate the distance
				distance = self._dist_calc(data, row[:-1])
				distances.append([index, distance, row[-1]])

			# sort the list
			distances.sort(key=lambda item: item[1])

			# since the list is sorted, a first item is the nearest one to the sample data
			result.append(distances[0][2])

		return np.array(result)

	def conformal_predict(self, new_data):
		afps = []
		preds = []
		p_values = []
		for data in new_data:
			for cls in self.classes:
				self._temp_data = list(data)
				# appending the class to the data to calculate the conformity score with the whole dataset adding the data with all labels respectively
				self._temp_data.append(cls)

				# pushing back the new data to the dataset with certain label
				self._temp_data = np.concatenate((self._data, np.array(self._temp_data).reshape(1,len(self._temp_data))))

				# obtain the index of the new data
				temp_index = len(self._temp_data)

				# calcualte the conformity score for whole dataset
				conformity_scores = list(map(self._conformity_score, self._temp_data))

				# attach the indices to the data
				conformity_scores = [[i,x] for i,x in enumerate(conformity_scores)]

				# sort the list in descending order
				conformity_scores.sort(key=lambda item: item[1], reverse=True)

				# calculate P-value followed by appending
				# in this computation, "i" represents the rank of the sample, so we can just divide it by n+1, which is temp_index in this case
				p_values.append([ [cls, i/(temp_index)] for i,a in enumerate(conformity_scores) if a[0] == (temp_index-1) ][0])

			# sort the list in descending order
			p_values.sort(key=lambda item: item[1], reverse=True)

			# calculate the average false p value
			temp = np.sum([x[1] for x in p_values[1:]])
			afp = temp/(len(self.classes)-1)

			# prepare the return
			preds.append(p_values[0][0])
			afps.append(afp)
		return float(sum(afps))/float(len(afps)), np.array(preds)

	def _conformity_score(self, new_data):
		# calculate the distance one by one
		distances = [ [index, self._dist_calc(new_data[:-1], row[:-1]), row[-1]] for index, row in enumerate(self._temp_data) ]

		# sort the list in ascending order
		distances.sort(key=lambda item: item[1])

		# remove itself from the list
		distances = distances[1:]

		_class = distances[0][2]
		same_class_distance = distances[0][1]

		for d in distances:
			if int(d[2]) != int(_class):
				# since distances is sorted, we only pick the first(nearest) data from different class, and terminates the loop operation.
				other_class_diatance = d[1]

				if (same_class_distance == 0) or (other_class_diatance == 0):
					return 0
				else:
					return float(other_class_diatance) / float(same_class_distance)

	def _optional_conformity_score(self, new_data):
		# calculate the distance one by one
		distances = [ [index, self._dist_calc(new_data, row), row[-1]] for index, row in enumerate(self._data)]

		# sort the list
		distances.sort(key=lambda item: item[1])

		# remove itself from the list
		distances = distances[1:]

		_class = distances[0][2]
		same_class_distance = distances[0][1]

		if same_class_distance == 0:
			return 0
		else:
			return 1.0 / float(same_class_distance)

	def _sort(self, _list):
		# bubble sort algorithm
		for index in range(len(_list) - 1, 0, -1):
			for i in range(index):
				self._swap(_list, i)

	def _swap(self, _list, idx):
		if _list[idx] > _list[idx + 1]:
			_temp          = _list[idx]
			_list[idx]     = _list[idx + 1]
			_list[idx + 1] = _temp

	def _dist_calc(self, A, B):
		return np.sqrt(np.sum(np.square(np.subtract(A,B))))

	def score(self, X_test, y_test):
		y_pred = self.predict(X_test)
		return np.mean(y_pred == y_test)

	def cp_score(self, X_test, y_test):
		_, pred = self.conformal_predict(X_test)
		return np.mean(y_test==pred)

nn = NN(n_neighbors=1)
nn.fit(X_train_iris, y_train_iris)
print(nn.cp_score(X_test_iris, y_test_iris))
afp, _ = nn.conformal_predict(X_test_iris)
print(afp)

nn = NN(n_neighbors=1)
nn.fit(X_train_ionosphere, y_train_ionosphere)
print(nn.cp_score(X_test_ionosphere, y_test_ionosphere))
afp, _ = nn.conformal_predict(X_test_ionosphere)
print(afp)