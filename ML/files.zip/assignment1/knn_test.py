from collections import Counter

import numpy as np
from sklearn.datasets import load_iris

iris = load_iris()

X = np.genfromtxt("ionosphere.txt",delimiter=",")

from sklearn.model_selection import train_test_split
X_train_iris, X_test_iris, y_train_iris, y_test_iris = train_test_split(iris['data'], iris['target'], random_state=0)
# last column of X is the label column, so we can specify it by X[:,-1]
X_train_ionosphere, X_test_ionosphere, y_train_ionosphere, y_test_ionosphere = train_test_split(X, X[:,-1], random_state=0)


class KNN:
	def __init__(self, n_neighbors):
		self._n_neighbors = n_neighbors

	def fit(self, features, label):
		self._features     = features
		self._label        = label
		self._dim_features = features.shape[1]

	def predict(self, new_data):
		## algorithm of K nearest neighbour is here!!

		# distance to be compared
		prev_distance = []

		# output
		result = []

		for data in new_data:
			# calculate the distance one by one
			for index, row in enumerate(self._features):
				# calculate the distance
				distance = self._dist_calc(row, data)

				prev_distance.append([distance, index])

			# self._sort(prev_distance)
			self._timsort(prev_distance)
			result.append(self._vote(prev_distance))
		return np.array(result)

	def _dist_calc(self, A, B):
		return (sum((A - B) ** 2))**1/2

	# timsort algorithm
	def _timsort(self, _list):
		def myfunc(item):
			return item[0]

		_list.sort(key=myfunc)

	def _sort(self, _list):
		# bubble sort algorithm
		for index in range(len(_list) - 1, 0, -1):
			for i in range(index):
				self._swap(_list, i)

	def _swap(self, _list, idx):
		if _list[idx] > _list[idx + 1]:
			_temp          = _list[idx]
			_list[idx]     = _list[idx + 1]
			_list[idx + 1] = _temp

	def _vote(self, prev_distance):
		_temp = []
		for index in range(self._n_neighbors):
			_temp.append(self._label[prev_distance[index][1]])

		elems, counts = np.unique(_temp, return_counts=True)
		_temp = []

		for a,b in zip(elems, counts):
			_temp.append((a,b))
		self._timsort(_temp)
		return _temp[-1][0]

	def score(self, X_test, y_test):
		y_pred = self.predict(X_test)
		print(y_pred)
		return np.mean(y_pred == y_test)


def predict(X_train, y_train, x_test, k):
	# create list for distances and targets
	distances = []
	targets = []

	for i, data in enumerate(X_train):
		# first we compute the euclidean distance
		distance = np.sqrt(np.sum(np.square(x_test - data)))

		# add it to list of distances
		distances.append([distance, i])

	# sort the list
	distances = sorted(distances)

	# make a list of the k neighbors' targets
	for i in range(k):
		index = distances[i][1]
		targets.append(y_train[index])

	# return most common target
	return Counter(targets).most_common(1)[0][0]

y_hat = []
for i in range(len(X_test_iris)):
	y_hat.append(predict(X_train_iris, y_train_iris, X_test_iris[i, :], 3))
print(np.mean(y_hat == y_test_iris))
nn = KNN(n_neighbors=3)

nn.fit(X_train_iris, y_train_iris)
print(nn.score(X_test_iris, y_test_iris))

nn.fit(X_train_ionosphere, y_train_ionosphere)
print(nn.score(X_test_ionosphere, y_test_ionosphere))
