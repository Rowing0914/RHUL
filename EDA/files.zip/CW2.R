# ===== Q1 =====
library(ggplot2)

# check the distribution of carat
ggplot(diamonds, aes(x=diamonds$carat)) + geom_histogram(center=0.01, binwidth=0.01)

# take a subset of diamonds which has relatively large carat
diamonds <- subset(diamonds, diamonds$carat>0.8 & diamonds$carat<1.2)

# discretise the subset by the stepsize of 0.05
diamonds$carat_range <- cut(diamonds$carat, seq(0.8,1.2,0.05))

attach(diamonds)

# table of aggregated price with regard to the carat of the diamonds
aggregate(price,list(carat_range),mean)

# barchart
ggplot(diamonds) + geom_bar(aes(carat_range)) + ylab("Price") + xlab("Carat Range")


# ===== Q2 =====
library(tidyr)

wide_table <- read.table(header=TRUE, text="
Country Population.1960 Population.1980 Population.2000
Ruritania 1200  2400  600
Atlantis  17  67  68
Oceania 15000 20000 53000
Eurasia 39000 120000  230000
")

# transpose the wide table
long_table <- data.frame(t(wide_table[-1]))

# rename the columns in long table
colnames(long_table) <- wide_table[, 1]