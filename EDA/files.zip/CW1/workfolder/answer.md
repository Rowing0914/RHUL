

## ID: 2290 Coursework Question 1

## Q1. What information is in the dataset? What do the measure of cut, clarity, and colour mean?

In the dataset, we have 10 different attributes which characterise observations.

1. **Carat**:  weight of the diamond (0.2–5.01)
2. **Cut**:  quality of the cut (Fair, Good, Very Good, Premium, Ideal)
3. **Color**:  quality of the cut (Fair, Good, Very Good, Premium, Ideal)
4. **Clarity**: a measurement of how clear the diamond is (I1 (worst), SI2, SI1, VS2, VS1, VVS2, VVS1, IF (best))
5. **depth**:  length in mm (0–10.74)
6. **table**:  length in mm (0–10.74)
7. **price**:  price in US dollars ($326–$18,823)
8. **x**:  length in mm (0–10.74)
9. **y**:  length in mm (0–10.74)
10. **z**:  length in mm (0–10.74)

Within these 10 attributes, there are 4 particularly important attributes, which are called The **4Cs of Diamonds** in general. The 4Cs of diamonds consist of four properties of a diamond, which are **cut, colour, clarity, and carat.**

- **Cut**: the biggest factor in creating sparkle and fire, and without a high cut grade even a diamond of high quality can appear dull and lifeless. A diamond cut poorly and too deep can face-up smaller than it actually is.
- **Color**: the second most important characteristic. The highest quality diamonds are colourless, while those of lower quality have noticeable colour, which manifests as pale yellow in diamonds.
- **Clarity**: the least important factor, and it is the assessment of small imperfections on the surface and internally.
- **Carat**: Carat is the most misunderstood of the 4Cs. It actually refers to a diamond's weight, not the diamond’s size.

So, Among the 4Cs, the most important factor is the cut, on the other hand, the least important factor is the clarity.



## Q2. Does the dataset look as if it correctly constructed? What basic checks could we do?

First of all, we can plot price and weight against the physical ordering of the data. 

![2_1_diamonds_price](C:\Users\kosak\Desktop\RHUL\rhul_eda\CW1\workfolder\2_1_diamonds_price.png)

As you can see, partially the dataset contains some strange data which may cause some inconsistent result later on. But we do not know why this happened. Then, we also could check the consistency of x, y and z measurements with weight (carat). 

![2_2_xyz_carat](C:\Users\kosak\Desktop\RHUL\rhul_eda\CW1\workfolder\2_2_xyz_carat.png)

By looking at the generated graph, there is an outlier(data: 24068) on the far right hand-side. Yet mostly it shows the positive linear relationship. Also, we need to understand the distributions of the variables(mainly 4Cs) by plotting them using histograms. Initially, we tried to use the bins=30 though, it didn't show the clear distribution of the variables. So, we should carefully choose the number of bins. 

![2_3_carat_distribution](C:\Users\kosak\Desktop\RHUL\rhul_eda\CW1\workfolder\2_3_carat_distribution.png)

![2_3_clarity_dist](C:\Users\kosak\Desktop\RHUL\rhul_eda\CW1\workfolder\2_3_clarity_dist.png)

![2_3_cut_distr](C:\Users\kosak\Desktop\RHUL\rhul_eda\CW1\workfolder\2_3_cut_distr.png)

As we can see, overall the qualitative variables(cut, clarity) has shown nice distributions, whereas regarding carat the data structure looks quite spiky.

 Lastly, since we are interested in the relationship between 4Cs and the prices, it is better for us to check the distribution of the prices by plotting in a histogram. 

![2_4_price_dist](C:\Users\kosak\Desktop\RHUL\rhul_eda\CW1\workfolder\2_4_price_dist.png)

And the above graph clearly indicates the prices around 1500 do not exist, so when we do more investigation, we need to keep this finding in mind.

  Throughout the checking process we have done in this section, I believe that we can say that mostly the dataset is collected correctly though, still we have some outliers and weirdly some parts of prices do not exist in the dataset. So we can more investigate.



## Q3. How is weight(in carats) related to price?

As we did in the previous section, assuming that the dataset is sufficiently collected correctly, we would like to move on to identify the relationship between the carats and the prices of the diamonds. For the sanity check, let's see the whole distribution of the prices as below.

![3_1_price_dist](C:\Users\kosak\Desktop\RHUL\rhul_eda\CW1\workfolder\3_1_price_dist.png)

As we confirmed in the last section, there is a gap at about 1500 in price. But basically it shows that the expensive diamonds are rare.

  Then we would like to verify the Messing's theory, which holds that the price is proportional the equation below;
$$
\exp(C \times weight^{\frac{1}{3}})
$$
![3_1_,messings_theory](C:\Users\kosak\Desktop\RHUL\rhul_eda\CW1\workfolder\3_1_,messings_theory.png)

As it shows that it might seem that we should use log-log plotting because the relationship is not clearly linear. To do log-log plot, we just scale x and y variables by the logarithm function.

![3_2_log_log](C:\Users\kosak\Desktop\RHUL\rhul_eda\CW1\workfolder\3_2_log_log.png)

As we can see from the graph above, mainly there are two things noticeable in it. Firstly, it is a positive linear relationship. Secondly, at around the smaller carat, the carat is clearly discretised with respect to some range of the prices.

## Q4. What are the distribution of clarity, colour, and cut?

In this section, we will move on to check the distributions of 4Cs one by one.

![4_colour_dist](C:\Users\kosak\Desktop\RHUL\rhul_eda\CW1\workfolder\4_colour_dist.png)

As for the colour, it nicely shows the peak and tails. So, this might follow the gaussian distribution.

![4_cut_dist](C:\Users\kosak\Desktop\RHUL\rhul_eda\CW1\workfolder\4_cut_dist.png)

As for the cut property, it is easy to see that the commonest is `ideal`.

![4_carat_dist](C:\Users\kosak\Desktop\RHUL\rhul_eda\CW1\workfolder\4_carat_dist.png)

From the carat view-point, as we have confirmed earlier, it contains some outliers and spiky peaks.

![4_clarity_dist](C:\Users\kosak\Desktop\RHUL\rhul_eda\CW1\workfolder\4_clarity_dist.png)

Lastly, as for the clarity of the diamonds, it nicely shows the peak and tails. So, this might follow the gaussian distribution.



## Q5. How do clarity, colour, and cut affect price?

In this section, we would like to identify the relationship between the prices and 4Cs except carats because we did it earlier. First let's try boxplots of price versus each property in 4Cs except carat. 

![5_1_cut](C:\Users\kosak\Desktop\RHUL\rhul_eda\CW1\workfolder\5_1_cut.png)

With regard to the cut, we can say that `ideal` has unexpectedly low average price compared to classes. 

![5_1_clarity](C:\Users\kosak\Desktop\RHUL\rhul_eda\CW1\workfolder\5_1_clarity.png)

As for the clarity, in `I1` class, there are some outliers exist. Regarding other classes, we can confirm that `IF` and `WS1` has relatively low variances.

![5_1_colour](C:\Users\kosak\Desktop\RHUL\rhul_eda\CW1\workfolder\5_1_colour.png)

Lastly, as for the colour, `J`  and `I` have relatively high prices.

  At next, to avoid the confounding effect of size, let us select diamonds from a narrow range of weights; if we can find enough diamonds in some narrow weight-ranges, then weight will not affecting the prices. To do this, we will take two subsets of the dataset following the condition where one is that the diamonds has carat in the range of 0.49 to 0.55 and the other is that the diamonds has carat in the range of 0.99 to 1.2. Then we will see the relationship between each properties and the prices by using the boxplot again.

![5_3_clarity](C:\Users\kosak\Desktop\RHUL\rhul_eda\CW1\workfolder\5_3_clarity.png)

As it showed above, compared to the original one, it became clearer to see the difference among classes. In original boxplot, IF had the lowest average price though, in this subset of data, we can see that IF has the biggest average price. Also, in most classes, the variance has been decreased.

![5_3_cut](C:\Users\kosak\Desktop\RHUL\rhul_eda\CW1\workfolder\5_3_cut.png)

As for cut, in most classes, the variance has been decreased and unlike the original graph, `ideal` has the largest average price.

![5_3_colour](C:\Users\kosak\Desktop\RHUL\rhul_eda\CW1\workfolder\5_3_colour.png)

At last, in colour, one thing noticeable is that class `J` has the lowest average price whereas in original boxplot, it had the largest one.

In conclusion, by looking at the graphs above, it is safe to say that although there are some difference in degree of correlation between the variable (in 4Cs) and the prices, basically 4Cs affects the prices.



## Q7. Write down two questions that you could answer with these data, and use appropriate visualisation and summary statistics to answer them

### 1. How does differentiate the half carat diamonds from one carat diamonds?

As far as I have visualised the distributions of 4Cs in the half and one carat diamonds dataset, the biggest difference arises in cut as below.

![cut_dist_halfcarat](C:\Users\kosak\Desktop\RHUL\rhul_eda\CW1\workfolder\cut_dist_halfcarat.png)

![cut_dist_one_carat](C:\Users\kosak\Desktop\RHUL\rhul_eda\CW1\workfolder\cut_dist_one_carat.png)

As it is clear to see, the number of `Ideal` diamonds in half carat is far largest among the other classes in the half carat, whereas the one in the one carat dataset is relatively less different from `Premium`. So we can say that the size of diamonds correlates to the cut of diamonds.

### 2. Does "Ideal" mean literally ideal diamonds?

So, in the second question, I would like to investigate more about the `Ideal` diamonds. To confirm the difference of the impact in price, I would like to separate the dataset in two parts which one is `ideal` diamonds and the other is `fair`, then check the difference of the distributions in the prices.

![ideal_price_dist](C:\Users\kosak\Desktop\RHUL\rhul_eda\CW1\workfolder\ideal_price_dist.png)

![fair_price_dist](C:\Users\kosak\Desktop\RHUL\rhul_eda\CW1\workfolder\fair_price_dist.png)

Looking at both distributions, frankly there is no eye-level difference between them. So, we might question more that although it says `Ideal`, does it really guarantee what we are thinking?  And to know the answer for this, I think we need to check the original definition `Ideal`.

