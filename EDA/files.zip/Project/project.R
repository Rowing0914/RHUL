# The dataset contains 27 island nations with their economic indicator, demographic element,
# geographical characteristic and tourism factors from 2000 to 2012

"  ====== Data Description ======
   country: Name of the country, indexed by an integer
      year: Range from 0 to 12 representing a 13 year time frame
       pop: Population of a country
   areakm2: Area of a country in km2
    gdpnom: Gross domestic product (GDP) of the country, indicating the economic development
flights-WB: Number of flights
    hotels: Number of hotels
  hotrooms: Number of hotel rooms
   receipt: Tourism receipts, which defined (by WTO) as expenditure of international inbound visitors including their payments to national carriers for international transport. They also include any other payments or payments afterwards made for goods and services received in the destination country.
  ovnarriv: Overnight arrival
  dayvisit: Number of visit days
     arram: Number of arrivals from America
    arreur: Number of arrivals from Europe
    arraus: Number of arrivals from Australia
"

# ==== Data Investigation ====
df <- read.csv("world_bank_international_arrivals_islands.csv", stringsAsFactors = F)
df <- data.frame(data.matrix(df))
summary(df)
" ====== Result ======
351 x 14 data matrix

  country        year         pop             areakm2          gdpnom           flights...WB   
Min.   : 1   Min.   : 0   Min.   :   9400   Min.   :   26   Min.   :1.300e+07   Min.   :  1128  
1st Qu.: 7   1st Qu.: 3   1st Qu.:  69325   1st Qu.:  298   1st Qu.:3.802e+08   1st Qu.:  8811  
Median :14   Median : 6   Median : 156700   Median :  459   Median :7.520e+08   Median : 13644  
Mean   :14   Mean   : 6   Mean   : 491219   Mean   : 2095   Mean   :9.684e+09   Mean   : 22425  
3rd Qu.:21   3rd Qu.: 9   3rd Qu.: 494900   3rd Qu.: 2040   3rd Qu.:4.194e+09   3rd Qu.: 21249  
Max.   :27   Max.   :12   Max.   :5312500   Max.   :28400   Max.   :2.770e+11   Max.   :154429  
                          NA's   :25                        NA's   :49          NA's   :193     
   hotels        hotrooms        receipt             ovnarriv           dayvisit           arram       
Min.   :  23   Min.   :  230   Min.   :8.000e+05   Min.   :    1100   Min.   :   1000   Min.   :     4  
1st Qu.:  95   1st Qu.: 1782   1st Qu.:4.600e+07   1st Qu.:   37500   1st Qu.:  21250   1st Qu.:  4000  
Median : 106   Median : 4889   Median :1.650e+08   Median :  129500   Median : 315000   Median : 16000  
Mean   : 271   Mean   : 7597   Mean   :6.892e+08   Mean   :  750799   Mean   : 485411   Mean   : 98674  
3rd Qu.: 158   3rd Qu.:10497   3rd Qu.:5.575e+08   3rd Qu.:  406500   3rd Qu.: 603750   3rd Qu.:171000  
Max.   :4673   Max.   :47312   Max.   :1.799e+10   Max.   :11952000   Max.   :2898000   Max.   :564000  
NA's   :290    NA's   :266     NA's   :55          NA's   :37         NA's   :261       NA's   :232     
   arreur            arraus     
Min.   :    100   Min.   :   91  
1st Qu.:   3000   1st Qu.:  289  
Median :  21000   Median :  857  
Mean   : 198859   Mean   : 5354  
3rd Qu.: 221500   3rd Qu.: 8974  
Max.   :1414000   Max.   :22693  
NA's   :232       NA's   :286   
"

# check the ratio of NAs in a data
colMeans(is.na(df))
" ====== Result ======
   country         year          pop      areakm2       gdpnom flights...WB       hotels     hotrooms 
0.00000000   0.00000000   0.07122507   0.00000000   0.13960114   0.54985755   0.82621083   0.75783476 
   receipt     ovnarriv     dayvisit        arram       arreur       arraus 
0.15669516   0.10541311   0.74358974   0.66096866   0.66096866   0.81481481
"

# ==== List Questions ====
# 1. How much does the expenditure of tourism contribute to the economy of a country?
# 2. Which country shows the strong momentum of GDP?

# ===== Q1 =====
# make an index: the contribution rate of tourism in Economy
df$GDP_receipt <- df$receipt/df$gdpnom
attach(df)

# re-organise the dataset
a = aggregate(GDP_receipt, list(country), mean, na.rm=TRUE)
b = as.numeric(as.character(unlist(a[[2]])))
c = as.numeric(as.character(unlist(a[[1]])))

# visualise the disbtribution of the contribution rate among countries
barplot(b, names.arg =c(c))

# group countries w.r.t the contribution rates of tourism in Economy
library(arules)
new_df = data.frame(unique(country), b)

# attach the economic growth rate to the dataframe
new_df$ave_GDP <- aggregate(receipt, list(country), mean, na.rm=TRUE)

new_df$label <- discretize(b)
names(new_df) <- c("country", "ave_GDP", "contribution_rate", "label")

# visualise a contribution rate by facetting in 3
library(ggplot2)
ggplot(new_df, aes(new_df$country, new_df$ave_GDP)) + geom_point() + facet_grid(rows=new_df$label) + xlab("Countries in 3 diff groups") + ylab("Average GDP over 13 years")


# ===== Q2 =====
library(forecast)
remove(new_df2)
new_df2 = data.frame(country, year, gdpnom)
new_df2$label <- new_df$label
new_df$growth_rate <- new_df2[,14]/new_df2[,2]

ggplot(new_df, aes(new_df$country, new_df$growth_rate)) + geom_point() + facet_grid(rows=new_df$label) + xlab("Countries in 3 diff groups") + ylab("Growth rate of GDP over 13 years")
