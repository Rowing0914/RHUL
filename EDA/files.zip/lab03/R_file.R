# ===== Labwork =====
# saving graph to your worksheet
# p + ggtitle("title comes here!")

# Q1. What information is in the dataset? What do the measure of cut, clarity, and colour mean?
# I summarised this information in pdf

# Q2. Does the dataset look as if it correctly constructed? What basic checks could we do?
# 2.1 Plot price and weight against the physical ordering of the data
library(ggplot2)
attach(diamonds)

p <- ggplot(diamonds, aes(x=1:nrow(diamonds), y=price)) + geom_point()
p + scale_x_continuous(limits=c(43700, 44100))
p <- ggplot(diamonds[43700:44100,], aes(x=43700:44100,y=price)) + geom_point()
p + ggtitle("subset of diamonds over the price") + xlab("subset of diamonds") + ylab("price")

# 2.1 checking consistency of x,y and z measurements with weight(carat)
ggplot(diamonds, aes(x=(x*y*z), y=carat)) + geom_point()
# by looking at the generated graph, I found some outliers on the right handside.
# but mostly it shows the positive linear relationship.

which.max(x=(x*y*z))
# 24068

# 2.3 studying the distributions of the variables
p <- ggplot(diamonds, aes(x=carat)) + geom_histogram()
# defualt bin: 30
p

# i think we should choose the bin carefully by trial and error more!
p <- ggplot(diamonds, aes(x=carat, fill=clarity)) + geom_histogram(center=0.01, binwidth=0.01)
p

# the seq function
caratbreaks <- seq(0.2, 5.2, by=0.1)
p + scale_x_continuous(breaks=caratbreaks) + ggtitle("Carat distribution")

# 2.4 checking the distribution of prices
# plotting the distribution of prices with the bins=300
p <- ggplot(diamonds, aes(x=price, fill=clarity)) + geom_histogram(bins=300)
p

p + scale_x_continuous(minor_breaks = seq(500,15000,by=100), limits=c(1000,2000))

# Q3. How is weight(in carats) related to price?
# 3.1 According to Messing's theory, price is proportional to exp(C x weight^(1/3)). Is this plausible?
p <- ggplot(diamonds, aes(x=carat^(1/3), y=price)) + geom_point() + scale_y_log10()
p

# 3.2 Might a power law fit the data better?
p <- ggplot(diamonds, aes(x=carat^(1/3), y=price)) + geom_point() + scale_y_log10() + scale_x_log10()
p

# Q4. What are the distribution of clarity, colour, and cut?
ggplot(diamonds,aes(x=color)) + geom_bar()
ggplot(diamonds,aes(x=cut)) + geom_bar()
ggplot(diamonds,aes(x=carat)) + geom_bar()
ggplot(diamonds,aes(x=clarity)) + geom_bar()

# Q5. How do clarity, colour, and cut affect price?
# 5.1 First try: boxplots of price versus clarity
ggplot(diamonds, aes(x=clarity, y=price)) + geom_boxplot()
ggplot(diamonds, aes(x=clarity, y=price)) + geom_violin()

# 5.2 Does the distribution of clarity, colour, and cut change with carat-weight?
caratfactor <- cut(carat, quantile(carat), include.lowest=TRUE)
diamonds$caratfactor <- caratfactor
attach(diamonds)

ggplot(diamonds, aes(x=caratfactor, fill=clarity)) + geom_bar()

ggplot(diamonds, aes(x=caratfactor, fill=clarity)) + geom_bar(position="fill")

# 5.3 The effect of clarity, colour, and cut on price: second attemp
halfcaratdiamonds <- subset(diamonds, carat>0.49 & carat<0.55)
onecaratdiamonds <- subset(diamonds, carat>0.99 & carat<1.2)

ggplot(halfcaratdiamonds, aes(clarity,y=price)) + geom_boxplot()
ggplot(halfcaratdiamonds, aes(cut,y=price)) + geom_boxplot()
ggplot(halfcaratdiamonds, aes(color,y=price)) + geom_boxplot()

# Q6. Is there any interaction between clarity, colour and cut in determinig the price?
ggplot(subset(diamonds,carat>0.99 & carat<1.2 & cut == "Ideal"), aes(x=clarity, y=price)) + geom_boxplot() + facet_grid(.~color) + scale_y_log10()

diamondsonecarat <- subset(diamonds, carat>0.99 & carat<1.1 & cut == "Ideal")
# install.packages("plyr")
library(plyr)
library(ggplot2)
diamonds$caratfactor <- caratfactor
attach(diamonds)

d1cmeans <- ddply(diamondsonecarat, .(clarity, color), summarize, meanprice=mean(price))
ggplot(d1cmeans, aes(x=clarity, y=meanprice, color=color, group=color)) + geom_point() + scale_y_log10() + geom_line()


# Q7. Write down two questions that you could answer with these data,
# and use appropriate visualisation and summary statistics to answer them.

# ==== My questions ====
# 1. What is the distribution of the price, and what is the max and min of price?
# I always wonder what is the distribution of the prices of diamonds, do they sell such a cheap one?
# So using the histogram, I have confirmed its distribution and the max and min of it.
which.max(price)
max(price)
which.min(price)
min(price)
ggplot(diamonds, aes(x=price)) + geom_histogram(bins=100)

# 2. Does "Ideal" mean exactly ideal diamonds?
# Looking at the cut, we can ensure that it is classified as "Ideal", but does it really guarantee what we are thinking?
# So, i would like to investigate a little bit more of the definition of "Ideal" based on the dataset.
ideal_diamonds <- subset(diamonds, cut=="Ideal")
fair_diamonds <- subset(diamonds, cut=="Fair")

ggplot(ideal_diamonds, aes(x=price, fill=clarity)) + geom_histogram(bins=300)
ggplot(fair_diamonds, aes(x=price, fill=clarity)) + geom_histogram(bins=300)

# according to the result, I don't think the definition of "Ideal" is not exactly what we imaigne by hearing "Ideal"....
