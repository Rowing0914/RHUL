defmodule TwoProcesses do

  def run(token1, token2 ) do
    pid1 = spawn( fn -> receive do 
                    { sender, token } -> 
                      send(sender, token*token)
                    end
                  end
                )
    pid2 = spawn( fn -> receive do 
                    { sender, token } -> 
                      send(sender, token*token)
                    end
                  end
                )

    send(pid1, {self(), token1 })
    send(pid2, {self(), token2 })

    ans1 = receive do
      answer1 -> IO.puts(answer1)
                 answer1
      end
    ans2 = receive do
      answer2 -> IO.puts(answer2)
                 answer2
      end
    ans1 * ans2
  end
end
