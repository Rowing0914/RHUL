defmodule TwoProcesses do

  def computeSquare() do 
    receive do 
      { sender, token } -> send(sender, token*token)
   end
  end

  def run(token1, token2 ) do
    pid1 = spawn( TwoProcesses, :computeSquare, [])
    pid2 = spawn( TwoProcesses, :computeSquare, [])

    send(pid1, {self(), token1 })
    send(pid2, {self(), token2 })

    ans1 = receive do
      answer1 -> IO.puts "Got #{answer1}" 
                 answer1
      end
    ans2 = receive do
      answer2 -> IO.puts "Got #{answer2}" 
                 answer2
      end
    IO.puts(ans1 * ans2)
  end
end
