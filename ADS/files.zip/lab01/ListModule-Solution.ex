defmodule ListModule do
  @moduledoc "A module containing various list functions"

  @doc "Computes the length of a list"
  def len([]), do: 0
  def len([_ | tail]) do
    1 + len(tail)
  end

  @doc "Computes the factorial of an integer"
  def fac(0), do: 1
  def fac(1), do: 1
  def fac(x) when x > 0 do
    x * fac(x-1)
  end

  @doc "flattens a given list. See lecture slides."
  def flatten([]), do: []
  def flatten([head | tail]) do
    flatten(head) ++ flatten(tail)
  end
  def flatten(singleton), do: [singleton]

  def sum(list), do: do_sum(list,0)

  defp do_sum([],acc), do: acc
  defp do_sum([head|tail],acc) do
    do_sum(tail,acc+head)
  end

  @doc "span function. See lecture slides."
  def span(from,to) when from>to, do: []
  def span(from,to) do
    [from | span(from+1,to)]
  end

  @doc "Tail-recursive version of flatten. See lecture slides."
  def flatten1(list), do: do_flatten(list,[])

  defp do_flatten([],result), do: Enum.reverse(result)
  defp do_flatten([[h | []] | tail],result) do
    do_flatten([h|tail],result)
  end
  defp do_flatten([[h | t] | tail ],result) do
    do_flatten([h,t | tail],result)
  end

  defp do_flatten([head|tail],result) do
    do_flatten(tail, [head|result])
  end

  def span1(from,to), do: do_span(from,to,[])

  defp do_span(from,to,result) when from>to do
      Enum.reverse(result)
  end
  defp do_span(from,to,result) do
    do_span(from+1,to,[from|result])
  end
end
