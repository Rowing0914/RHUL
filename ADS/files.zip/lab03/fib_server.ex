defmodule Fib do 
  @doc "This is the server entry point"
  def scheduler(caller) do 
    _scheduler = spawn(Fib,:run,[])
    send(caller, { :ready, _scheduler })
  end
  
  def run() do
    receive do
        {num_processes, job_list} -> 
            IO.puts("SCHEDULER: Starting to spawn children")
            list_processes  = spawn_processes(1, num_processes)
            isDone = assign_jobs(list_processes, job_list, num_processes)
        {:answer, n, result} ->
            IO.puts("SERVER: Starting to collect the result")
    end
 end

  def server_run() do
    receive do
      {:compute, n, client} -> 
        IO.puts("SERVER: Starting to compute F(#{n})...")
        send(client, { :answer, n, fib_calc(n) })
        IO.puts("SERVER #{inspect(self())}: Done computing F(#{n})")
        run()
      {:shutdown} -> 
        IO.puts("SERVER: #{inspect(self())} exiting...")
        exit(:normal)
    end
  end

  @doc "Spawn the processes and put them into the list"
  def spawn_processes(from,to) when from>to, do: []
  def spawn_processes(from,to) do
    [spawn(Fib, :server_run, []) | spawn_processes(from+1,to)]
  end

  @doc "Assign the tasks to the servers"
  def assign_jobs(list_processes, job_list, num_processes) when len(job_list) == 0, do: []
  def assign_jobs(list_processes, job_list, num_processes) do
    for i <- 1..num_processes do
        send(list_processes[i], {:compute, job_list[i]})
    end
  end

    
  @doc "Computes the length of a given list"
  def len([]), do: 0
  def len([_ | tail]) do
    1 + len(tail)
  end


  # Very inefficiently computes Fibonacci numbers up to n:
  def fib_calc(0), do: 0
  def fib_calc(1), do: 1
  def fib_calc(n), do: fib_calc(n-1) + fib_calc(n-2)
end

Fib.server(self())
server_pid = receive do
  {:ready,server_pid} -> server_pid
end

range = 20..40

for i <- range do
  send( server_pid, {:compute, i, self()}) 
end

for i <- range do
  receive do 
    { :answer, i, result } -> 
        IO.puts( "Received result from server: F(#{i}) = #{result}")
  end
end

send(server_pid, {:shutdown})
