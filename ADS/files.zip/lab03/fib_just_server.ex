defmodule Fib do 
  @doc "This is the server entry point"
  def server(caller) do 
    p1 = spawn(Fib,:run,[])
    send(caller, { :ready, p1 })
  end
    
  def run() do
    receive do
      {:compute, n, client} -> 
        IO.puts("SERVER: Starting to compute F(#{n})...")
        send(client, { :answer, n, fib_calc(n) })
        IO.puts("SERVER #{inspect(self())}: Done computing F(#{n})")
        run()
      {:shutdown} -> 
        IO.puts("SERVER: #{inspect(self())} exiting...")
        exit(:normal)
    end
  end

  # Very inefficiently computes Fibonacci numbers up to n:
  def fib_calc(0), do: 0
  def fib_calc(1), do: 1
  def fib_calc(n), do: fib_calc(n-1) + fib_calc(n-2)
end

Fib.server(self())
server_pid = receive do
  {:ready,server_pid} -> server_pid
end

range = 20..40

for i <- range do
  send( server_pid, {:compute, i, self()}) 
end

for i <- range do
  receive do 
    { :answer, i, result } -> 
        IO.puts( "Received result from server: F(#{i}) = #{result}")
  end
end

send(server_pid, {:shutdown})
