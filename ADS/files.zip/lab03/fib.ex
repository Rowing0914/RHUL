defmodule Fib do 
  @doc "This is the server entry point"
  def server(caller) do 
    pid = spawn(Fib,:run,[%{}]) # spawn the server and initialize cache to %{}
    send(caller, { :ready, pid })
  end
    
  def run(cache) do
    receive do
      {:compute, n, client} -> 
        IO.puts("SERVER: Starting to compute F(#{n})...")
        {result,cache} = fib_eff(n,cache) 
        IO.puts("SERVER #{inspect(self())}: Done computing F(#{n})")
        send(client, { :answer, n, result })
        send(client, { :ready, self() })
        run(cache)

      {:shutdown} -> 
        IO.puts("SERVER: #{inspect(self())} exiting...")
        exit(:normal)
    end
  end

  # More efficient computation of Fibonacci numbers using memoization:
  def fib_eff(0,cache), do: {0,cache}
  def fib_eff(1,cache), do: {1,cache}
  def fib_eff(n,cache) do 
    # Check if F(n) is already in the cache:
    case Map.fetch(cache,n) do
      {:ok, v1} -> {v1,cache}
      :error    ->   # We haven't computed F(n) yet
        {v1,cache} = fib_eff(n-1,cache)
        {v2,cache} = fib_eff(n-2,cache)
        # Return result and also add entry key-value pair {n,F(n)} to cache:
        {v1+v2,Map.put_new(cache,n,v1+v2)} 
    end
  end
end

defmodule Scheduler do

  def start(num_processes, job_list) do
    # Create num_process many server instances:
    for _ <- 1..num_processes do
      Fib.server(self())
    end
    run( num_processes, job_list, [])
  end

  def run(num_processes, job_list, result_list) do
    receive do 
      {:ready, pid} -> 
        if length(job_list) > 0 do
          [ job_list_head | job_list_tail ] = job_list
          IO.puts("SCHEDULER: got ready from #{inspect pid}")
          send( pid, {:compute, job_list_head, self()}) 
          run( num_processes, job_list_tail, result_list )
        else 
          IO.puts("SCHEDULER: Sending shutdown to server instance with pid=#{inspect pid}, "
                  <>
                  "#{num_processes-1} server instances are still running.")
          send( pid, {:shutdown })
          if num_processes > 1 do
            run( num_processes - 1, job_list, result_list )
          else
            result_list
          end
        end

      {:answer, n, result } -> 
        IO.puts("SCHEDULER: Received result F(#{n})=#{result}")
        run( num_processes, job_list, [{n,result} | result_list])
    end
  end 
end

# Spawn 10 server instances and compute the first 5000 Fibonacci numbers.
Scheduler.start(10,Enum.to_list(1..5000))
