sshpass -p norio0925 scp -rp Coursework mfac012@linux.cim.rhul.ac.uk:/home/cim/pgt/mfac012/Desktop/

