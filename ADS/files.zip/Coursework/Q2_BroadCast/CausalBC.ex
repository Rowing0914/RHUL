defmodule COBroadcast do
  defp init_state(name,participants) do 
    %{ myname: name, 
       pending: [], 
       participants: participants,
       ts: for p <- participants, into: %{} do
             {p,0} 
           end
     }
  end

  def start(name,participants) do
    pid = spawn(COBroadcast,:run, [init_state(name,participants)]) 
  end

  def co_bc_send(msg, pid) do
    # this simulates Causally ordered BC
    send(pid, {:input, :co_bc_send, msg})
  end

  def run(state) do
    IO.puts("#{state.myname}: Executing run...")
    IO.puts("#{state.myname}'s timestamp estimates (ts): " <> inspect(state.ts))
    # register this process under name "state.myname" so other processes can 
    # find its pid
    :global.register_name(state.myname,self())
    
    state = receive do 
      {:input, :co_bc_send, msg} ->
        # update the own vector clock
        state = update_in(state, [:ts, state.myname], fn(t) -> t+1 end)
        # broadcast the message to other participants with own vector clock
        ssf_bc_send(state, {:bc_msg, msg, state.ts, state.myname})
        # update the pending list
        update_in(state,[:pending], fn(ls) -> [{msg, state.ts, state.myname}|ls] end )

      {:output,:bc_receive,origin_name,msg} -> 
        # here we just write to the screen that we TO-broadcast-delivered a message
        IO.puts("OUTPUT: #{state.myname} CO-BCAST-delivered broadcast msg #{msg} from #{origin_name}")
        state

      {:bc_msg, msg, t, origin_name} ->
        state = put_in(state, [:ts, origin_name], t)
        state = update_in(state, [:pending], fn(ls) -> [{msg, state.ts[origin_name], origin_name} | ls] end )
        state = if t > state.ts[state.myname] do
          ssf_bc_send(state, {:ts_up, t, state.myname})
          put_in(state, [:ts, state.myname], t)
        else
            state
        end

      {:bc_msg,msg,t,origin_name} -> 
        state = put_in( state, [:ts, origin_name], t)
        state = update_in( state, [:pending], fn(ls) -> [{msg,state.ts[origin_name],origin_name} | ls] end )
        state = if t > state.ts[state.myname] do
          ssf_bc_send(state,{:ts_up,t,state.myname})
          put_in( state, [:ts, state.myname], t)
        else
          state
        end

      {:ts_up,t,origin_name} -> 
        # handle a timestamp-update message by updating the timestamp estimate 
        # currently held for process with name origin_name, i.e. ts[origin_name].
        put_in( state, [:ts,origin_name], t)

      # debug api
      {:get, caller} ->
        IO.puts("get req from #{inspect(caller)}")
        send(caller, state)
    end

    # Find the messages ready to be removed from the pending list:
    readyMsgs = remove_pending(state, co_sort(state.pending))
    # Update local state by subtracting readyMsgs from the pending list:
    state = %{ state | pending: state.pending -- readyMsgs }

    if readyMsgs != [] do
      # for each "ready" message, we produce an output event for the upper layer, 
      # which we simulate by sending a "bc_receive" event message:
      for {msg,t,j} <- readyMsgs do
        send(self(),{:output,:bc_receive,j,msg})
      end
    end
    run(state)
  end # run() ends here!

  def co_remove_pending(_, []), do: []
  def co_remove_pending(state, [{msg, t, j} | rest]) do
     checks = for p <- state.participants do
                  (t[j] == state.ts[j]+1) && (t[p] <= state.ts[p])
              end
     if not(Enum.member?(checks, false)) do
         [{msg, t, j} | co_remove_pending(state, rest)]
     else
         co_remove_pending(state, rest)
     end
  end

  def co_sort([]), do: []
  def co_sort([m]), do: [m]
  def co_sort([{msg, t, j} | rest]) do
    smaller = Enum.filter( rest, fn({_,t1,j1}) -> (t1 < t) || ((t1 == t) && (j1 < j)) end )
    larger  = Enum.filter( rest, fn({_,t1,j1}) -> (t < t1) || ((t == t1) && (j < j1)) end )
    co_sort(smaller) ++ [{msg,t,j}] ++ co_sort(larger)
  end

  def remove_pending(_,[]), do: []
  def remove_pending(state,[{msg, t, j} | rest]) do
    checks = for p <- state.participants do
                 t <= state.ts[p]
             end
    if not(Enum.member?(checks,false)) do
      [{msg,t,j} | remove_pending(state,rest)]
    else
      remove_pending(state,rest)
    end
  end

  def ssf_bc_send(state,msg) do
     # send a message to everyone except myself using for-comprehension: 
     for p <- List.delete(state.participants, state.myname) do
        # lookup pid for name p:
        case :global.whereis_name(p) do
          :undefined -> IO.puts("ERROR participant #{p} has already terminated!")
          pid -> if( state.myname == "p1") do # we intentionally delay process p1
                   :timer.sleep(2000)
                 end
                 send(pid,msg)
       end
    end
  end
end

p1 = COBroadcast.start("p1", ["p1","p2","p3","p4"])
p2 = COBroadcast.start("p2", ["p1","p2","p3","p4"])
p3 = COBroadcast.start("p3", ["p1","p2","p3","p4"])
p4 = COBroadcast.start("p4", ["p1","p2","p3","p4"])

COBroadcast.co_bc_send("Hello everyone!",p1)
COBroadcast.co_bc_send("Hello everyone!",p2)
COBroadcast.co_bc_send("Hello everyone!",p3)
COBroadcast.co_bc_send("Hello everyone!",p4)
COBroadcast.co_bc_send("Hello (again)!",p1)
COBroadcast.co_bc_send("Hello again!",p4)
COBroadcast.co_bc_send("Hello again!",p2)
COBroadcast.co_bc_send("Hello again!",p3)