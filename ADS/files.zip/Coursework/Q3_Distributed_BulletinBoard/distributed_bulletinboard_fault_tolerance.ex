defmodule Topic do
  def start(topic_name) do
    {:ok, pid} = Task.start_link(fn -> run([]) end)
    :global.register_name(String.to_atom(topic_name), pid)
    TopicManager.start("TM_" <> topic_name)
  end

  defp run(content_list) do
    receive do
      {:post, caller, topic_name, content} ->
        IO.puts("TOPIC: received a post request")
        content_list = [content | content_list]
        IO.puts("TOPIC: content list: " <> inspect(content_list))
        send(caller, {:bc_content, inspect(Enum.at(content_list, 0))})
        run(content_list)
    end
  end
end

defmodule TopicManager do
  defp init_state(tm_name) do
    %{ topic_name: Enum.at(String.split(tm_name, "TM_"), 1),
       subscriber_list: []
     }
  end

  def start(tm_name) do
    {:ok, pid} = Task.start_link(fn -> run(init_state(tm_name)) end)
    :global.register_name(String.to_atom(tm_name), pid)
  end

  defp run(map) do
    receive do
      {:subscribe, user_name, topic_name} ->
        IO.puts("TM: received subscribe request")
        run(%{map | subscriber_list: [user_name | map.subscriber_list]})
      {:post, topic_name, content} ->
        IO.puts("TM: received post request and forward it to #{topic_name}")
        send(:global.whereis_name(String.to_atom(topic_name)), {:post, self(), topic_name, content})
        run(map)
      {:bc_content, content} ->
        IO.puts("TM: received bc_content request")
        bc_content(map.subscriber_list, content)
        run(map)
      {:get, caller} ->
        IO.puts("TM: received get request")
        send(caller, {:reply, inspect(map.subscriber_list)})
        run(map)
      {:unsubscribe, user_name, topic_name} ->
        IO.puts("TM: received unsubscribe request")
        new_list = List.delete(map.subscriber_list, user_name)
        map = Map.put(map, :subscriber_list, new_list)
        IO.puts(inspect(map))
        run(map)
    end
  end
 
  def bc_content(subscriber_list, content) do
    for p <- subscriber_list do
      case :global.whereis_name(String.to_atom(p)) do
        :undefined -> IO.puts("ERROR participant #{p} has already terminated!")
        pid -> 
          IO.puts("TM: Sending content(#{content}) to #{p}(#{inspect(pid)})")
          send(pid, {:new_topic, self(), content})
      end
    end
  end
end

defmodule User do
  def server do
    {:ok, pid} = Task.start_link(fn -> run([]) end)
    :global.register_name(:User, pid)
  end

  def start(user_name) do
    {:ok, pid} = Task.start_link(fn -> user_run() end)
    :global.register_name(String.to_atom(user_name), pid)
  end

  defp run(list) do
    receive do
      {:create_user, user_name, caller} ->
        IO.puts(inspect(list))
        list = [user_name | list]
        {:ok, pid} = Task.start_link(fn -> user_run() end)
        :global.register_name(String.to_atom(user_name), pid)
        send(caller, Enum.member?(list, user_name))
        run(list)
    end
  end

  defp user_run do
    receive do
      {:get, caller} ->
        send(caller, self())
        user_run()
      {:new_topic, pid, content} ->
        IO.puts("USER: new content arrival: " <> content)
        user_run()
    end
  end

  def subscribe(user_name, topic_name) do
    IO.puts("USER: subscribe")
    case :global.whereis_name(:BulletinBoard) do
      :undefined -> IO.puts("ERROR participant BulletinBoard has already terminated!")
      pid -> send(pid, {:subscribe, user_name, topic_name})
    end
  end

  def unsubscribe(user_name, topic_name) do
    IO.puts("USER: unsubscribe")
    case :global.whereis_name(:BulletinBoard) do
      :undefined -> IO.puts("ERROR participant BulletinBoard has already terminated!")
      pid -> send(pid, {:unsubscribe, user_name, topic_name})
    end
  end

  def post(user_name, topic_name, content) do
    IO.puts("USER: #{user_name} is going to post a content: #{content}")
    case :global.whereis_name(String.to_atom("TM_"<> topic_name)) do
      :undefined -> IO.puts("ERROR participant #{"TM_"<> topic_name} has already terminated!")
      pid -> 
        # IO.puts(inspect(pid))
        send(pid, {:post, topic_name, content})
    end
  end

  def fetch_news() do
    IO.puts("USER: fetch_news")
    # case :global.whereis_name(String.to_atom("TM_"<> topic_name)) do
    #   :undefined -> IO.puts("ERROR participant #{"TM_"<> topic_name} has already terminated!")
    #   pid -> 
    #     IO.puts(inspect(pid))
    #     IO.puts(inspect(self()))
    #     send(pid, {:fetch_news, self(), topic_name})
    # end
  end
end

defmodule BulletinBoard do
  def start do
    IO.puts("BULLETINBOARD: started")
    {:ok, pid} = Task.start_link(fn -> run([]) end)
    :global.register_name(:BulletinBoard, pid)
  end

  defp run(topic_list) do
    receive do
      {:get, caller} ->
        IO.puts(inspect(topic_list))
        send(caller, {:reply, inspect(topic_list)})
        run(topic_list)
      {:subscribe, user_name, topic_name} ->
        if Enum.member?(topic_list, topic_name) do
          # IO.puts("topic does exist")
          send(:global.whereis_name(String.to_atom("TM_" <> topic_name)), {:subscribe, user_name, topic_name})
          run(topic_list)
        else
          # IO.puts("topic does not exist")
          Topic.start(topic_name)
          # IO.puts("topic has been created")
          send(:global.whereis_name(String.to_atom("TM_" <> topic_name)), {:subscribe, user_name, topic_name})
          run([topic_name | topic_list])
        end
      {:unsubscribe, user_name, topic_name} ->
        send(:global.whereis_name(String.to_atom("TM_" <> topic_name)), {:unsubscribe, user_name, topic_name})
        run(topic_list)
    end
  end
end

defmodule Dummy do
  def start do
    IO.puts("spawning")
    pid = Node.spawn_link(:"alpha@noio0925", run())
    IO.puts("#{inspect(pid)}")
    IO.puts(:global.register_name(:Dummy, pid))
    IO.puts(:global.whereis_name(:Dummy))
  end

  def run() do
    IO.puts("new process!")
    receive do
      {:hello, caller} ->
        IO.puts("Hello from #{inspect(caller)}")
        run()
    end
  end
end

defmodule Supervisor do
  def start do
    Task.start_link(fn -> run() end)
  end

  def run() do
    receive do
      {:start_monitor, caller} ->
        # monitor the network and if the other node enters or leaves
        # get noticed by the message the msg interface is described below
        # On enter: {:nodeup, node_name}
        # On leave: {:nodedown, node_name}
        IO.puts("#{inspect(self())} started monitoring")
        :ok = :net_kernel.monitor_nodes(true)
        run()
      {:check_nodes, caller} ->
        # check if this process is in a cluster
        IO.puts("#{inspect(self())} started checking other nodes")
        list_of_nodes = [node() | Node.list()]
        number_of_nodes = list_of_nodes |> Enum.count()
        if number_of_nodes > 1 do 
          IO.puts("In a cluster")
        else
          IO.puts("Not in a cluster")
        end
        run()
      {:nodeup, node_name} ->
        # On enter of the other node
        IO.puts("#{inspect(node_name)} entered to the network!!")
        IO.puts("I am going to replicate my processes on new man!")
        Dummy.start()
        IO.puts("finished spawning")
        run()
      {:nodedown, node_name, process_name} ->
        # On leave of the other node
        IO.puts("#{inspect(node_name)} left the network!!")
        IO.puts("So, I am going to replace the faulty one!")
        :global.register_name(String.to_atom(process_name), self())
        run()
    end
  end
end

# Assume that we have already three sessions on the terminal named as below
# iex --sname "alpha" --cookie test process_crash_example.ex
# iex --sname "beta" --cookie test process_crash_example.ex
# iex --sname "gamma" --cookie test process_crash_example.ex

# Node.connect(:"alpha@noio0925")
# Node.connect(:"beta@noio0925")
# Node.connect(:"gamma@noio0925")

# User.start("Alice")
# User.start("Bob")

# BulletinBoard.start()
# User.subscribe("Alice", "computing")
# User.subscribe("Bob", "computing")
# IO.puts("Pid of Alice: " <> inspect(:global.whereis_name(:Alice)))
# IO.puts("Pid of Bob: " <> inspect(:global.whereis_name(:Bob)))
# IO.puts("Pid of computing: " <> inspect(:global.whereis_name(:computing)))
# IO.puts("Pid of TM_computing: " <> inspect(:global.whereis_name(:TM_computing)))
# IO.puts("Pid of BulletinBoard: " <> inspect(:global.whereis_name(:BulletinBoard)))
# send(:global.whereis_name(:TM_computing), {:get, self()})
# receive do
#   {:reply, msg} -> IO.puts(msg)
# end

# User.post("Alice", "computing", "Surprise motherfucker!!")
# User.post("Bob", "computing", "That's what she said!")

# :timer.sleep(2000)
# User.unsubscribe("Bob", "computing")
# User.fetch_news()