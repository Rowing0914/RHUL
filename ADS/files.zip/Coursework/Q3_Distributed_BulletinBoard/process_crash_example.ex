# # Test 1 : single process failure
# pid = spawn(fn ->
#   :timer.sleep 500
#   raise("Sorry, my friend.")
# end)

# # Set up a monitor for this pid
# ref = Process.monitor(pid)

# # Wait for a down message for given ref/pid
# receive do
#   {:DOWN, ^ref, :process, ^pid, :normal} ->
#     IO.puts "Normal exit from #{inspect pid}"
#   {:DOWN, ^ref, :process, ^pid, msg} ->
#     IO.puts "Received :DOWN from #{inspect pid}"
#     IO.inspect msg
# end


# # Test 2 : a node monitoring the other node
# # Execute the commands below from the terminal
# # Preparation: iex --sname "alpha" , iex --sname "beta"
# # Nodes: [alpha@noio0925, beta@noio0925]

# # from alpha@noio0925
# :net_kernel.monitor_nodes(true)

# # from beta@noio0925
# Node.connect(:"alpha@noio0925")


# # Test 3 : a node monitoring the other node
# # Execute the commands below from the terminal
# # Preparation: iex --sname "alpha" , iex --sname "beta"
# # Nodes: [alpha@noio0925, beta@noio0925]

# # from beta@noio0925
# Node.monitor(:"alpha@noio0925", true)

# # from alpha@noio0925
# # this kills the node!!
# # :init.stop() 


# Test 4 : a process monitoring the network

# defmodule Test do
# 	def start do
# 		Task.start_link(fn -> run() end)
# 	end

# 	def run() do
# 		receive do
# 			{:start_monitor, caller} ->
# 				# monitor the network and if the other node enters or leaves
# 				# get noticed by the message the msg interface is described below
# 				# On enter: {:nodeup, node_name}
# 				# On leave: {:nodedown, node_name}
# 				IO.puts("#{inspect(self())} started monitoring")
# 				:ok = :net_kernel.monitor_nodes(true)
# 				run()
# 			{:check_nodes, caller} ->
# 				# check if this process is in a cluster
# 				IO.puts("#{inspect(self())} started checking other nodes")
# 				list_of_nodes = [node() | Node.list()]
# 				number_of_nodes = list_of_nodes |> Enum.count()
# 				if number_of_nodes > 1 do 
# 					IO.puts("In a cluster")
# 				else
# 					IO.puts("Not in a cluster")
# 				end
# 				run()
# 			{:nodeup, node_name} ->
# 				# On enter of the other node
# 				IO.puts("#{inspect(node_name)} entered to the network!!")
# 				run()
# 			{:nodedown, node_name} ->
# 				# On leave of the other node
# 				IO.puts("#{inspect(node_name)} left the network!!")
# 				run()
# 		end
# 	end
# end

# {:ok, pid} = Test.start()
# send(pid, {:start_monitor, self()})
# Node.connect(:"alpha@noio0925")
# IO.puts("Node in the network: #{inspect(Node.list)}")
# send(pid, {:check_nodes, self()})
# :timer.sleep(500)
# Node.disconnect(:"alpha@noio0925")

# Test 5 : a process monitoring the network and if the other node crashes,
# then the process will be replacing with the faulty one with the same global name

defmodule Target do
	def start(process_name) do
		{:ok, pid} = Task.start_link(fn -> run() end)
    :global.register_name(String.to_atom(process_name), pid)
    IO.puts("Target process named #{process_name} is running in #{inspect(pid)}")
	end

	def run() do
		receive do
			{:hello, caller} ->
				IO.puts("Hello from #{inspect(caller)}")
				run()
		end
	end
end

defmodule Dummy do
	def start do
		IO.puts("spawning")
		pid = Node.spawn_link(:"alpha@noio0925", run())
		IO.puts("#{inspect(pid)}")
    IO.puts(:global.register_name(:Dummy, pid))
		IO.puts(:global.whereis_name(:Dummy))
	end

	def run() do
		IO.puts("new process!")
		receive do
			{:hello, caller} ->
				IO.puts("Hello from #{inspect(caller)}")
				run()
		end
	end
end

defmodule Supervisor do
	def start do
		Task.start_link(fn -> run() end)
	end

	def run() do
		receive do
			{:start_monitor, caller} ->
				# monitor the network and if the other node enters or leaves
				# get noticed by the message the msg interface is described below
				# On enter: {:nodeup, node_name}
				# On leave: {:nodedown, node_name}
				IO.puts("#{inspect(self())} started monitoring")
				:ok = :net_kernel.monitor_nodes(true)
				run()
			{:check_nodes, caller} ->
				# check if this process is in a cluster
				IO.puts("#{inspect(self())} started checking other nodes")
				list_of_nodes = [node() | Node.list()]
				number_of_nodes = list_of_nodes |> Enum.count()
				if number_of_nodes > 1 do 
					IO.puts("In a cluster")
				else
					IO.puts("Not in a cluster")
				end
				run()
			{:nodeup, node_name} ->
				# On enter of the other node
				IO.puts("#{inspect(node_name)} entered to the network!!")
				IO.puts("I am going to replicate my processes on new man!")
				Dummy.start()
				IO.puts("finished spawning")
				run()
			{:nodedown, node_name} ->
				# On leave of the other node
				IO.puts("#{inspect(node_name)} left the network!!")
				IO.puts("So, I am going to replace the faulty one!")
		    :global.register_name(String.to_atom(process_name), self())
				run()
		end
	end
end

{:ok, pid} = Supervisor.start()
send(pid, {:start_monitor, self()})
Node.connect(:"alpha@noio0925")
IO.puts("Node in the network: #{inspect(Node.list)}")
send(pid, {:check_nodes, self()})
IO.puts(Process.alive?(pid))
IO.puts(:global.whereis_name(:Dummy))
:timer.sleep(500)
Node.disconnect(:"alpha@noio0925")