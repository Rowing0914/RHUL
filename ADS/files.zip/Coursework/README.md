### Q1. Explain the main characteristics of distributed programming in Erlang/Elixir. Describe the purpose of processes and nodes and how they can interact to jointly compute problems in a distributed fashion. (200– 250 words)

## Answer
#### Characteristics of distributed programming in Erlang/Elixir
There are mainly four features in Erlang/Elixir.
1. **Fault-Tolerance**: If something happens. it has an only local impact(Isolation).
2. **Scalability**: Erlang VM, which is BEAM, consists of multiple processes communicating to provide a service.
3. **Distributed computing**: Following the asynchronous/synchronous message passing model, each process works independently.
4. **Responsiveness**: Pre-emptive scheduling, per-process garbage collection.
With those features above, Erlang/Elixir is called Concurrency-oriented functional programming language.

#### Purpose of processes and nodes and how they interact with each other to finish given tasks in a distributed fashion.
Processes are in charge of computing problems in a node, whereas a node in a distributed network represents a machine containing processes inside. Then, those processes are spawned on a scheduler which works on a CPU of the machine. So we can assume that the variables used in processes on a scheduler are well maintained and updated concurrently.
With the output/input channels connecting processes in nodes, processes execute a sequence of two different events in turn. Deliver event has processes send the resulting message to other process on the output channel and subsequently in computing event processes would work on own tasks based on the received message/input on the input channel.
Based on this message passing protocol, the distributed processes working in each node will try coming to the agreement for the outcome of the task using certain consensus algorithms. 


### Q2. Broadcast
## Answer
Please check `Q2_BroadCast/CausalBC.ex`


### Q3. Distributed Bulletin Board
### (a)
Please check `Q3_Distributed_BulletinBoard/Description_of_Program.pdf`

### (b)
Please check `Q3_Distributed_BulletinBoard/distributed_bulletinboard.ex`

### (c)
Please check `Q3_Distributed_BulletinBoard/distributed_bulletinboard_fault_tolerance.ex`


### Q4. Consider a broadcast implementation B that has the following ordering guarantees: If messages m1 and m2 are received by a non-faulty process pi , then (1) every other non-faulty process pj is guaranteed to also receive m1 and m2, and (2) pi and pj receive m1 and m2 in the same order. Outline a high-level argument why it is impossible to implement B in an asynchronous point-to-point message passing system, when up to f > 0 out of n > f processes can fail by crashing. Hint: You can assume the fact that implementing consensus is impossible in this setting.

### Answer
Suppose in contradiction the implementing consensus is possible in this setting. I define the important terms as below.
	* Agreement: All decisions by correct processes must be the same
	* Validity: Only proposed values may be decided
	* Termination: All correct processes eventually decide
In the given statements (1) and (2) in the question, although they guarantee regarding the order of the received messages by certain process in the network, they do not ensure no message loss caused by n(>f>0) faulty processes. Hence, some processes will keep waiting for the lost message during its delivery event. So this does not hold the termination property that the implementation of B is impossible in an asynchronous point-to-point message passing system.
QED