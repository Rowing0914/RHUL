a = [1, 2, 3]
b = [4, 5, 6]

for index, (i, j) in enumerate(zip(a, b)):
    print(index, i, j)
