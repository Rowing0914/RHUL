import mlreportgen.report.*
import mlreportgen.dom.*

rpt = Report('assignment_report');
chapter = Chapter();
chapter.Title = 'Task4: Train/Test MSE';
add(rpt,chapter);

add(rpt, report_table);

chapter = Chapter();
chapter.Title = 'Task6';
add(rpt,chapter);
boxplot(log);
fig = Figure();
fig.Snapshot.Caption = 'Task6: Result of 100 times';
fig.Snapshot.Height = '5in';
add(rpt, fig);

delete(gcf);
rptview(rpt);