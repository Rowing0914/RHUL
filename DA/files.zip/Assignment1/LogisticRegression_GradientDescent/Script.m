format longG

% Parameters
num_attributes = 6;

% ======= Task 2 ======= 
load Auto.mat;

% Normalise data
data = normalize([Auto.horsepower, Auto.weight, Auto.year]);

% update the whole Auto dataset for later usage
Auto.horsepower = data(:,1);
Auto.weight = data(:,2);
Auto.year = data(:,3);

% create new column
Auto.high = Auto.mpg >= 23;

% convert categorical data into one hot vector(dummy variables)
vec = reshape(Auto.origin, [1, length(Auto.origin)]);
Auto.origin = full(ind2vec(vec))';
Auto.origin = Auto.origin(:,1:2);

% ======= Task 3 ======= 
mybirthday = 925;
rng(mybirthday);
index_rand = randi([int8(height(Auto)/2), height(Auto)], 1);

% create training dataset and obtain its indices
[train, used_idx] = datasample(Auto, index_rand);

% create the unused indices in training dataset
indices = 1:height(Auto);
indices(used_idx) = [];

% create test dataset using the left indices from training dataset
test = Auto(indices, :);

% ======= Task 4 ======= 
v_min = -0.7;
v_max = 0.7;

% initialsie weitghts
weights = random_with_range(v_min, v_max, num_attributes);

col_for_bias_train = ones(length(train.horsepower),1);
col_for_bias_test = ones(length(test.horsepower),1);

% Prepare data
train_X = [col_for_bias_train, train.horsepower, train.weight, train.year, train.origin];
train_y = train.high;
test_X = [col_for_bias_test, test.horsepower, test.weight, test.year, test.origin];
test_y = test.high;

% Number of training steps
num_steps = [1,5,10,20,30]';
learning_rate = [0.001,0.01,0.1,1,10]';
train_results = [];
test_results = [];

for i = 1:5
    % train the model using GD
    [weights, log_errors, temp_] = GD(train_X, train_y, weights, num_steps(i), learning_rate(i));
    fprintf('Training MSE: %d\n', min(log_errors));

    % validation stage
    y_pred = Logistic_Regression(test_X, weights);
    [rows, cols] = size(test_X);
    test_MSE = 1/rows*sum((test_y - y_pred).^2);
    fprintf('Test MSE: %d\n', test_MSE);
    
    train_results = [train_results, min(log_errors)];
    test_results = [test_results, test_MSE];
end

% ======= Task 6 =======
log = [];
for i = 1:100
    % initialsie weitghts
    weights = random_with_range(v_min, v_max, num_attributes);

    % train the model using GD
    [weights, log_errors, temp_] = GD(train_X, train_y, weights, 50, 10);
    fprintf('LoopNo: %d, Training MSE: %d\n', i, min(log_errors));

    % validation stage
    y_pred = Logistic_Regression(test_X, weights);
    test_MSE = 1/rows*sum((test_y - y_pred).^2);
    fprintf('LoopNo: %d, Test MSE: %d\n', i, test_MSE);
    log = [log, test_MSE];
end

% visualise the log in boxplot
boxplot(log);
% saveas(gcf, 'task6.png')

% Create report
test_results = test_results';
train_results = train_results';
report_table = table(num_steps, learning_rate, train_results, test_results);
report_generator;