function result = random_with_range(v_min, v_max, n)
% this generates the vector containing the random values within a specific range
result = v_min + (v_max - v_min).*rand(1,n);
end