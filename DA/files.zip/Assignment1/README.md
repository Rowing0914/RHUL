## Coursework: Assignment 1
### Directory Architecture
- LogisticRegression_GradientDescent : Logistic Regression with Gradient Descent
- NeuralNetworks : Neural Networks *Unfortunately, I couldn't finish it. But I would like to receive some feedback. So I have decided to leave it here.*

## Notes on LogisticRegression_GradientDescent
* Tasks1: I have chosen to MSE for Objective function(`GD.m` line17).
* Tasks2: From line 6 in `Script.m`. Also the dummy vector conversion of the column `origin` is done there.
* Tasks3: From line 25 in `Script.m`. My birthday is 25/09/1992, so I removed zero at first digit to follow the specified format('MMDD')
* Tasks4: From line 40 in `Script.m`. Also, the resulting table is stored in `assignment_report.pdf`.
* Tasks5: From line 23 in `GD.m`. Thanks to this condition, we can finish training the model earlier compared to just iterate through it in fixed times.
* Tasks6: From line 77 in `Script.m`. Also, the resulting box plot is stored in `assignment_report.pdf`.
* Tasks7: I could not figure out.