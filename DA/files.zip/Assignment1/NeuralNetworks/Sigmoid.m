function result = Sigmoid(data)
% this computes the value following the logistic regression algorithm

result = (1+exp(-data)).^-1;
end