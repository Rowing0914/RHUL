function result = Derivative_Cross_Entropy_with_Softmax(true_label, prediction)
% this is the derivated Cross Entropy algorithm with softmax
result = true_label - prediction;
end