% sample network
% layers: 2 3 1
% input: 2x2
% output: 1

X = randn(2,2);
y = randi(5);
layers = [2 3 1];

weights = cell(numel(layers)-1, 1);

for i = 1:numel(layers)-1
    weights{i} = randn(layers(i+1), layers(i));
end

[row, col] = size(X);

for i = 1:row
    % layer1 => layer2
    a1 = Sigmoid(weights{1}*X(i,:)');
    
    % layer2 => layer3
    o = Softmax(weights{2}*a1);
    
    % compute error
    Error = Cross_Entropy(true_label, o);
    
    % layer2 <= layer3
    delta_error1 = Derivative_Cross_Entropy_with_Softmax(true_label, o);
    weights{2} = weights{2} + learning_rate*delta_error1*a1;
    
    % layer1 <= layer2
    delta_error2 = delta_error1*weights{2}*X(i,:);
    weights{1} = weights{1} + learning_rate*delta_error2;
end