function [weights, log_errors, log_weight] = NN(X, y, layers, num_epoch, learning_rate)
% this is the implementation of Neural Networks
% Params:
%   X : Features
%   y : True Labels
%   layers : array of number of neurons in each layer respectively
%   num_epoch : number of maximum epoch

log_errors = [];
log_weight = [];
threshold = 0;
count = 0;

[rows, cols] = size(X);

% check the given structure of the network
if layers == 0
    error('Please give me an appropriate structure of the network!');
elseif layers(1) ~= rows
    error('Your input has wrong dimensions')
end

% initialise the weights for each layer
weights = cell(numel(layers)-1, 1);

for i = 1:numel(layers)-1
    weights{i} = randn(layers(i+1), layers(i));
end


for epoch = 1:num_epoch
    y_pred = Sigmoid(X, weights);
    MSE = sum((y - y_pred).^2);
    Error = y - y_pred;
    d = 2*Error.*Derivative_Sigmoid(X, weights);
    update_value = ((learning_rate/col1)*d')*X;
    weights = weights + update_value;

    % optional task(5)
    if (epoch > 1) && (MSE > threshold)
        count = count + 1;
    end

    if count == 10
        fprintf('Epoch: %d, your training is done!!\n', epoch);
        break
    end
    % update the threshold
    threshold = MSE*0.99;

    % update the training history
    log_errors = [log_errors; MSE];
    log_weight = [log_weight; weights];
end

end