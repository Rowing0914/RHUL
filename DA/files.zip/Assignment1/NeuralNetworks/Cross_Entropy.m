function result = Cross_Entropy(p ,q)
% this compute the cross entropy loss among the 2 given distributions
result = - sum(p.*log(q)');
end