# library(MASS)
# library(ISLR)
# # fix(Boston)
# data(Boston)
# attach(Boston)
# lm.fit <- lm(medv~lstat)
# lm.fit
# names(lm.fit)
# coef(lm.fit)
# predict(lm.fit, data.frame(lstat=c(5,10,15)))
# plot(lstat, medv)
# abline(lm.fit)
# abline(lm.fit, lwd=3)
# abline(lm.fit, lwd=3, col="red")
# plot(lstat, medv, col="red")
# plot(lstat, medv, pch=20)
# plot(lstat, medv, pch="+")
# plot(1:20, 1:20, pch=1:20)
# lm.fit <- lm(medv~lstat+age, data=Boston)
# lm.fit
# lm.fit <- lm(medv~., data=Boston)
# lm.fit
# plot(lstat, medv)
# abline(lm.fit)
# 
# # fix(Carseats)
# names(Carseats)
# attach(Carseats)
# lm.fit <- lm(Sales~., data=Carseats)
# lm.fit
# contrasts(ShelveLoc)
# 
# names(Smarket)
# summary(Smarket)
# attach(Smarket)
# glm.fit <- glm(Direction~Lag1+Lag2+Lag3+Lag4+Lag5+Volume, data=Smarket, family=binomial)
# glm.fit
# coef(glm.fit)
# glm.probs <- predict(glm.fit, type="response")
# glm.probs[1:6]
# contrasts(Direction)
# glm.pred <- rep("Down", 1250)
# glm.pred[glm.probs>.5] <- "Up"
# table(glm.pred, Direction)
# mean(glm.pred==Direction)
# train <- (Year<2005)
# Smarket.2005 <- Smarket[!train, ]
# dim(Smarket.2005)
# Direction.2005 <- Direction[!train]
# glm.fit <- glm(Direction~Lag1+Lag2+Lag3+Lag4+Lag5+Volume,data=Smarket, family=binomial, subset = train)
# glm.probs <- predict(glm.fit, Smarket.2005, type="response")
# glm.pred <- rep("Down", 252)
# glm.pred[glm.probs>.5] <- "Up"
# table(glm.pred, Direction.2005)
# mean(glm.pred!=Direction.2005)
# glm.fit <- glm(Direction~Lag1+Lag2,data=Smarket, family=binomial, subset=train)
# glm.probs <- predict(glm.fit, Smarket.2005, type="response")
# glm.pred <- rep("Down", 252)
# glm.pred[glm.probs>.5] <- "Up"
# table(glm.pred, Direction.2005)
# mean(glm.pred==Direction.2005)
# predict(glm.fit, newdata=data.frame(Lag1=c(1.2, 1.5), Lag2=c(1.1, -0.8)), type="response")
# 
# 
# library(class)
# train.X <- cbind(Lag1,Lag2)[train,]
# test.X <- cbind(Lag1,Lag2)[!train,]
# train.Direction <- Direction[train]
# set.seed(1)
# knn.pred <- knn(train.X, test.X, train.Direction, k=1)
# table(knn.pred, Direction.2005)
# knn.pred <- knn(train.X, test.X, train.Direction, k=3)
# table(knn.pred, Direction.2005)



# ============= exercises =============
# 1. This problem involves the Auto data set. Use the lm() function to perform a simple linear regression with mpg as the label and horsepower as the attribute.
# (a) Is the relationship between the attribute and the label positive or negative for this data set?
# (b) What is the predicted mpg associated with a horsepower of 98?
# (c) Plot the label and the attribute. Use the abline() function to display the least squares regression line.
library(MASS)
library(ISLR)
library(class)

attach(Auto)
attach(Boston)
attach(Carseats)

lm.fit <- lm(mpg~horsepower, data=Auto)
coef(lm.fit)
# (Intercept)  horsepower 
# 39.9358610  -0.1578447
# (a): Negative

predict(lm.fit, data.frame(horsepower=98))
# (b): 24.46708

# (c)
plot(mpg, horsepower)
abline(lm.fit, lwd=3, col="red")


# 2. This problem involves the Boston data set. 
# We will try to predict per capita crime rate using the other variables in this data set. 
# In other words, per capita crime rate is the label, and the other variables are the attributes. 
# (If this looks too tiresome, use a subset of two or three variables
# that look most promising to you as the attributes.)
# (a) For each attribute, fit a simple linear regression model to predict the label.
# (b) Fit a multiple regression model to predict the label using all of the attributes.
# (c) How do your results from item 2a compare to your results from item 2b? Create a plot displaying the univariate regression coefficients from item 2a on the x-axis, and the multiple regression coefficients from item 2b on the y-axis. That is, each attribute is displayed as a single point in the plot. Its coefficient in the simple linear regression model is shown on the x-axis, and its coefficient in the multiple linear regression model is shown on the y-axis.
# (d) Is there evidence of non-linear association between any of the attributes and the label? To answer this question, for each attribute X, fit the learning machine
#     Y = β0 + β1X + β2X2 + β3X3

# (a)
# result = c()
# count = 1
# for (attr in names(Boston)) {
#   if (attr == 'crim') {
#     next
#   }
#   print(attr)
#   lm.fit <- lm(crim~attr, data=Boston)
#   result[count] = coef(lm.fit)[[2]]
#   count = count + 1
# }

lm.fit <- lm(crim~zn, data=Boston)
coef(lm.fit)[[2]]
lm.fit <- lm(crim~indus, data=Boston)
coef(lm.fit)[[2]]
lm.fit <- lm(crim~chas, data=Boston)
coef(lm.fit)[[2]]
lm.fit <- lm(crim~nox, data=Boston)
coef(lm.fit)[[2]]
lm.fit <- lm(crim~rm, data=Boston)
coef(lm.fit)[[2]]
lm.fit <- lm(crim~age, data=Boston)
coef(lm.fit)[[2]]
lm.fit <- lm(crim~dis, data=Boston)
coef(lm.fit)[[2]]
lm.fit <- lm(crim~rad, data=Boston)
coef(lm.fit)[[2]]
lm.fit <- lm(crim~tax, data=Boston)
coef(lm.fit)[[2]]
lm.fit <- lm(crim~ptratio, data=Boston)
coef(lm.fit)[[2]]
lm.fit <- lm(crim~black, data=Boston)
coef(lm.fit)[[2]]
lm.fit <- lm(crim~lstat, data=Boston)
coef(lm.fit)[[2]]
lm.fit <- lm(crim~medv, data=Boston)
coef(lm.fit)[[2]]

coeffs = c(-0.07393498,0.5097763,-1.892777,31.24853,-2.684051,0.1077862,-1.550902,0.6179109,0.02974225,1.151983,-0.03627964,0.5488048,-0.3631599)

# (b)
lm.fit <- lm(crim~., data=Boston)
result = c()
count = 1
for (x in coef(lm.fit)) {
  print(x)
  result[count] = x
  count = count + 1
}
result

# (c)
plot(coeffs, tail(result, -1))


# (d)

glm.fit <- glm(crim~zn+zn**2+zn**3, data=Boston)
coef(glm.fit)[[2]]
glm.fit <- glm(crim~indus+indus**2+indus**3, data=Boston)
coef(glm.fit)[[2]]
glm.fit <- glm(crim~chas+chas**2+chas**3, data=Boston)
coef(glm.fit)[[2]]
glm.fit <- glm(crim~nox+nox**2+nox**3, data=Boston)
coef(glm.fit)[[2]]
glm.fit <- glm(crim~rm+rm**2+rm**3, data=Boston)
coef(glm.fit)[[2]]
glm.fit <- glm(crim~age+age**2+age**3, data=Bosto)
coef(glm.fit)[[2]]
glm.fit <- glm(crim~dis+dis**2+dis**3, data=Boston)
coef(glm.fit)[[2]]
glm.fit <- glm(crim~rad+rad**2+rad**3, data=Boston)
coef(glm.fit)[[2]]
glm.fit <- glm(crim~tax+tax**2+tax**3, data=Boston)
coef(glm.fit)[[2]]
glm.fit <- glm(crim~ptratio+ptratio**2+ptratio**3, data=Boston)
coef(glm.fit)[[2]]
glm.fit <- glm(crim~black+black**2+black**3, data=Boston)
coef(glm.fit)[[2]]
glm.fit <- glm(crim~lstat+lstat**2+lstat**3, data=Boston)
coef(glm.fit)[[2]]
glm.fit <- glm(crim~medv+medv**2+medv**3, data=Boston)
coef(glm.fit)[[2]]

# 3. In this problem, you will develop a model to predict whether a given car gets high or low petrol mileage based on the Auto data set.
# (a) Create a binary variable, mpg01, that contains a 1 if mpg contains a value above its median, and a 0 if mpg contains a value below its median. You can compute the median using the median() function.
# (b) Explore the data graphically in order to investigate the association between mpg01 and the other variables. Which of the other variables look most useful in predicting mpg01? Scatterplots and boxplots may be useful tools to answer this question.
# (c) Split the data into a training set and a test set.
# (d) Perform logistic regression on the training data in order to predict mpg01 using the variables that seemed most associated with mpg01 in item 3b. What is the test error of the model obtained?
# (e) Perform KNN on the training data, with several values of K, in order to predict mpg01. Use only the variables that seemed most associated with mpg01 in item 3b. What test errors do you obtain? Which value of K seems to perform the best on this data set?

# (a)
mpg01 = ifelse(mpg>median(mpg),1,0)

# (b)
# append new column to original dataset
Auto$mpg01 <- paste(mpg01)
Auto$mpg01 <- sapply(Auto$mpg01, as.numeric)
pairs(Auto, col=mpg01)

# (c)
set.seed(2)
train <- sample(1:nrow(Auto), 200)
test <- Auto[-train,]

# (d)
glm.fit <- glm(mpg01~cylinders, data=Auto, family=binomial, subset=train)
glm.probs <- predict(glm.fit, test, type="response")
glm.pred <- rep(0, length(glm.probs))
glm.pred[glm.probs>.5] <- 1
table(glm.pred, mpg01[-train])
1-mean(glm.pred==mpg01[-train])
# test error rate: 12.5% (0.125)

# (e)
result = c()
count = 1
for (k in 1:20) {
  knn.pred <- knn(cbind(cylinders, origin)[train,], cbind(cylinders, origin)[-train,], mpg01[train], k=k)
  result[count] = 1-mean(knn.pred==mpg01[-train])
  count = count + 1
}
plot(result)
# According to the generated graph, we could say that K=6 is the best paramete.

# 4. Using the Boston data set, fit classification models in order to predict
# whether a given suburb has a crime rate above or below the median.
# Explore logistic regression and KNN models using various subsets of the
# attributes.
data(Boston)
attach(Boston)
crim01 = ifelse(crim>median(crim),1,0)
Boston$crim01 = paste(crim01)
Boston$crim01 = sapply(Boston$crim01, as.numeric)
pairs(Boston, col=crim01)

set.seed(2)

train <- sample(1:nrow(Boston), 350)
test <- Boston[-train,]

# Logistic Regression
glm.fit <- glm(crim01~lstat+nox, data=Boston, family=binomial, subset=train)
glm.probs <- predict(glm.fit, test, type="response")
glm.pred <- rep(0, length(glm.probs))
glm.pred[glm.probs>.5] <- 1
table(glm.pred, crim01[-train])
1-mean(glm.pred==crim01[-train])
# test error rate for logistic regression: 0.2179487

# KNN
result = c()
count = 1
for (k in 1:50) {
  knn.pred <- knn(cbind(lstat, nox)[train,], cbind(lstat, nox)[-train,], crim01[train], k=k)
  result[count] = 1-mean(knn.pred==mpg01[-train])
  count = count + 1
}
plot(result)
# test error rate for KNN does vary very much.