# ============= Demo =============
# 1. Bagging and random forests

library(randomForest)
library(MASS)
train <- sample(1:nrow(Boston), nrow(Boston)/2)
bag.boston <- randomForest(medv~., data=Boston, subset=train, mtry=13)
bag.boston

yhat.bag <- predict(bag.boston, newdata=Boston[-train,])
boston.test <- Boston[-train, "medv"]
plot(yhat.bag, boston.test)
abline(0,1)
mean((yhat.bag-boston.test)^2)

set.seed(1)
rf.boston <- randomForest(medv~., data=Boston, subset=train, mtry=13, ntree=25)
yhat.rf <- predict(rf.boston, newdata=Boston[-train,])
mean((yhat.rf-boston.test)^2)

# 2. Boosting
library(gbm)
set.seed(1)
boost.boston <- gbm(medv~., data=Boston[train,], distribution="gaussian", n.trees = 5000, interaction.depth=4)
yhat.boost <- predict(boost.boston, newdata=Boston[-train, ], n.trees=5000)
mean((yhat.boost - boston.test)^2)

# ============= Exercise: the size of bootstrap samples =============
# We will derive the probability that a given observation is part of a bootstrap
# sample. Suppose that we obtain a bootstrap sample from a set of n observations.

# 1. What is the probability that the first bootstrap observation is not the jth
# observation from the original sample? Justify your answer (there is no need to write down your answer or justification).

# Answer: (n-1)/n

# 2. What is the probability that the second bootstrap observation is not the
# jth observation from the original sample? (There is no need to write down your answer.)

# Answer: (n-1)/n * (n-1)/n

# 3. Argue that the probability that the jth observation is not in the bootstrap
# sample is (1 − 1/n)^n (There is no need to write down your argument.)

# Answer: It's a product of the probability that you don't get the j-th observation in the bootstrap sample with replacement.

# 4. When n = 5, what is the probability that the jth observation is in the
# bootstrap sample? (There is no need to write down your answer.)

# Answer
n = 5
(1 - 1/n)^n
# 0.32768

# 5. When n = 100, what is the probability that the jth observation is in the
# bootstrap sample? Write down this probability.

# Answer
n = 100
(1 - 1/n)^n
# 0.3660323

# 6. When n = 10,000, what is the probability that the jth observation is in
# the bootstrap sample? (There is no need to write down your answer.)

# Answer
n = 10000
(1 - 1/n)^n
# 0.367861

# 7. Create a plot that displays, for each integer value of n from 1 to 100,000,
# the probability that the jth observation is in the bootstrap sample. Comment
# on what you observe. (There is no need to write down your comment.)
# Save your plot as a pdf file.

result = c()

for (n in 1:100000) {
  result[n] = 1 - (1 - 1/n)^n
}
plot(result)
