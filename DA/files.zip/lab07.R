states <- row.names(USArrests)
states
names(USArrests)
apply(USArrests, 2, mean)
apply(USArrests, 2, var)
pr.out <- prcomp(USArrests, scale=TRUE)
names(pr.out)
pr.out$center
pr.out$scale
pr.out$rotation
dim(pr.out$x)
biplot(pr.out, scale=0)
pr.out$rotation <- -pr.out$rotation
pr.out$out$x <- -pr.out$x
biplot(pr.out, scale=0)
pr.out$sdev
pr.var <- pr.out$sdev^2
pr.var
pve <- pr.var/sum(pr.var)
pve
plot(pve, xlab="Principal Component", ylab="Proportion of Variance Explained", ylim=c(0,1), type="b")
plot(cumsum(pve), xlab="Principal Component", ylab="Cumulative Proportion of variance Explained", ylim=c(0,1), type="b")
a <- c(1,2,8,-3)
cumsum(a)

# ======== Exercise ========
# 1. Generate a simulated data set with 20 observations in each of three classes (i.e., 60 observations total), and 50 variables.
rows = 20
cols = 50
cl1 = matrix( rnorm(rows*cols,mean=0,sd=1), rows, cols)
cl2 = matrix( rnorm(rows*cols,mean=1,sd=1), rows, cols)
cl3 = matrix( rnorm(rows*cols,mean=2,sd=1), rows, cols)
data = rbind(cl1,cl2,cl3)
labels = c(rep(1,20), rep(2,20), rep(3,20))

# Q2
pr.out <- prcomp(data)
dim(pr.out$x)
plot(pr.out$x[, 1:2], col=1:3, pch=19)

# 3. Perform K-means clustering of the observations with K = 3. How well do the clusters that you obtained in K-means clustering compare to the true class labels?
km = kmeans(data, 3, nstart = 20)
table(labels, km$cluster)

# 4. Now perform K-means clustering with K = 3 on the first two principal
# component score vectors, rather than on the raw data. That is, perform
# K-means clustering on the 60 × 2 matrix of which the first column is
# the first principal component score vector, and the second column is the
# second principal component score vector. Comment on your results.
km.pca = kmeans(pr.out$x[,1:2], 3, nstart = 20)
table(labels, km.pca$cluster)
