# x <- c(1,6,2)
# x <- c(1,
#        + 6,
#        + 2)
# y <- c(1,4,3)
# length(x)
# length(y)
# x+y
# ls()
# rm(x,y)
# ls()
# rm(list=ls())
# ?matrix
# x <- matrix(data=c(1,2,3,4), nrow=2, ncol=2)
# x <- matrix(c(1,2,3,4),2,2)
# y <- matrix(c(0,3,2,1),2,2)
# x %*% y
# x*y
# sqrt(x)
# x^2
# x <- rnorm(50)
# y <- x + rnorm(50, mean=50, sd=.1)
# cor(x,y)
# set.seed(1303)
# rnorm(50)
# set.seed(3)
# y <- rnorm(100)
# mean(y)
# var(y)
# sqrt(var(y))
# sd(y)
# x <- rnorm(100)
# y <- rnorm(100)
# plot(x,y)
# plot(x,y, xlab="this is the x-axis", ylab="this is the y-axis", main="Plot of X vs Y")
# pdf("Figure.pdf")
# plot(x,y,col="green")
# dev.off()
# x <- seq(1,10)
# print(x)
# x <- 1:10
# print(x)
# x <- seq(-pi, pi, length=50)
# plot(x, sin(x))
# A <- matrix(1:16,4,4)
# print(A)
# print(A[2,3])
# print(A[c(1,3), c(2,4)])
# print(A[1:3,2:4])
# print(A[1:2,])
# print(A[,1:2])
# print(A[1,])
# print(A[-c(1,3),])
# print(A[-c(1,3), -c(1,3,4)])
# library(ISLR)
# data("Auto")
# summary("Auto")
# fix(Auto)
# Auto <- na.omit(Auto)
# dim(Auto)
# names(Auto)
# attach(Auto)
# plot(cylinders, mpg)
# cylinders <- as.factor(cylinders)
# plot(cylinders, mpg)
# plot(cylinders, mpg, col="red")
# plot(cylinders, mpg, col="red", varwidth=T, norizontal=T)
# plot(cylinders, mpg, col="red", varwidth=T, xlab="cylinders", ylab="MPG")
# hist(mpg)
# hist(mpg, col=2)
# hist(mpg, col=2, breaks=15)
# pairs(Auto)
# pairs(~mpg+displacement+horsepower+weight+acceleration, Auto)
# plot(horsepower, mpg)
# identify(horsepower, mpg, name)
# summary(Auto)
# summary(mpg)

# Data import part

library(ISLR)
data("Auto")
summary("Auto")
Auto <- na.omit(Auto)
dim(Auto)
names(Auto)
attach(Auto)
cylinders <- as.factor(cylinders)

# ===================== Exercise =====================
# The following exercises involve the Auto data set. (If doing a task for each quantitative variable looks too tiresome, do it for at least three quantitative variables.)
# 1. Which of the variables are quantitative, and which are qualitative? (Answer this just looking at the data; there is no need to use any R commands.)
# 2. What is the range of each quantitative variable? You can answer this using the range() function.
# 3. What is the mean and standard deviation of each quantitative variable?
# 4. Now remove all observations from the 10th to 85th. What is the range, mean, and standard deviation of each quantitative variable in the subset of the data that remains?
# 5. Using the full data set, investigate the quantitative variables graphically, using scatterplots or other tools of your choice. Create some plots highlighting the relationships among the variables. Comment on your findings.
# 6. Suppose that we wish to predict gas mileage (mpg) on the basis of the other variables. Do your plots suggest that any of the other variables might be useful in predicting mpg? Justify your answer.


# 1. Which of the variables are quantitative, and which are qualitative? (Answer this just looking at the data; there is no need to use any R commands.)
# quantitative: 
#   "mpg"
#   "cylinders"
#   "displacement"
#   "horsepower"
#   "weight"
#   "acceleration"
#   "year"
#   "origin"
# 
# quantitative:
#   "name"

# 2. What is the range of each quantitative variable? You can answer this using the range() function.
print(range(Auto$mpg))
print(range(Auto$cylinders))
print(range(Auto$displacement))
print(range(Auto$horsepower))
print(range(Auto$weight))
print(range(Auto$acceleration))
print(range(Auto$year))
print(range(Auto$origin))

# 3. What is the mean and standard deviation of each quantitative variable?
print(mean(Auto$mpg))
print(mean(Auto$cylinders))
print(mean(Auto$displacement))
print(mean(Auto$horsepower))
print(mean(Auto$weight))
print(mean(Auto$acceleration))
print(mean(Auto$year))
print(mean(Auto$origin))

print(sd(Auto$mpg))
print(sd(Auto$cylinders))
print(sd(Auto$displacement))
print(sd(Auto$horsepower))
print(sd(Auto$weight))
print(sd(Auto$acceleration))
print(sd(Auto$year))
print(sd(Auto$origin))

# 4. Now remove all observations from the 10th to 85th. What is the range, mean, and standard deviation of each quantitative variable 
# in the subset of the data that remains?
data = Auto[-c(10:85),]

print(range(data$mpg))
print(range(data$cylinders))
print(range(data$displacement))
print(range(data$horsepower))
print(range(data$weight))
print(range(data$acceleration))
print(range(data$year))
print(range(data$origin))

print(mean(data$mpg))
print(mean(data$cylinders))
print(mean(data$displacement))
print(mean(data$horsepower))
print(mean(data$weight))
print(mean(data$acceleration))
print(mean(data$year))
print(mean(data$origin))

print(sd(data$mpg))
print(sd(data$cylinders))
print(sd(data$displacement))
print(sd(data$horsepower))
print(sd(data$weight))
print(sd(data$acceleration))
print(sd(data$year))
print(sd(data$origin))

# 5. Using the full data set, investigate the quantitative variables graphically, using scatterplots or other tools of your choice. 
# Create some plots highlighting the relationships among the variables. Comment on your findings.
pairs(Auto,col=Auto$origin)

# Written Answer
# As we can see from the plots, several pairs of features indicate strong positive linear correlation.
# For example, the one of displacement and horsepower can be confirmed easily.
# However, even though it has a certain relation of the features, as the colour of data indicates, origin-wise, origin of 0 mostly has relatively large standard deviation compared to other origin group.


# 6. Suppose that we wish to predict gas mileage (mpg) on the basis of the other variables.
# Do your plots suggest that any of the other variables might be useful in predicting mpg? Justify your answer.

# Written Answer
# As we can see from the plots, again mpg chiefly three variables show similar correlation, which are displacement, horsepower and weight.
# So to predict the value of mpg based on the given dataset, I would suggest to pick one variable from those three variables and select year feature as well.
# Because year feature shows certain randomness given the distribution on its plot against mpg.
# So, we can make the prediction model robust with this feature.