# ========= Task Description =========
# 1. Implement DS(Decision Stumps) and BDS(Boosted Decision Stumps).
# 2. Apply DS/BDS to Boston dataset to predict 'medv' given 'lstat' and 'rm'. **No need to Normalise them!!
# 3. Split the data randomly into two *equal* parts as training and test. Set your birthday(MMDD formatted) as the seed for the randomness.
# Answer the following questions:
  # Q1. Train your DS implementation on the training set. Find the MSE on the test set. Include it in your report.
  # Q2. Train your BDS implementation on the training set for learning rate eta = 0.01 and B = 1000 trees. Find the MSE on the test set. Include it in your report.
  # Q3. Plot the test MSE for a fixed value of eta as a function of B includes [1, B0] (the number of trees) for as large B0 as possible. 
      # Do you observe overfitting? Include the plot and answer in your report.

# ========= Answer =========

library(MASS)
# this is for unpack the returned values from the function using "list" appropriately
library(gsubfn)
library(tictoc)
attach(Boston)
options(warn=-1)

DS <- function(data, name, threshold){
  # create condition accordingly
  condition1 = data[name] < threshold
  condition2 = data[name] >= threshold
  
  # group observations into two
  data.g1 = data[name][condition1]
  data.g2 = data[name][condition2]

  # make prediction value for each group
  RSS_total = sum((data$medv[condition1] - ave(data.g1))**2) + sum((data$medv[condition2] - ave(data.g2))**2)
  
  # set the proper value to the return values
  if(length(data.g1) == 0){
    lessthan_value = 0
  } else {
    lessthan_value = ave(data.g1)[1]
  }
  if(length(data.g2) == 0){
    biggerthan_value = 0
  } else {
    biggerthan_value = ave(data.g2)[1]
  }
  # return multiple values in a vector manner
  return(c(RSS_total, threshold, lessthan_value, biggerthan_value))
}

training <- function(data, name, param) {
  result = c(100000000)
  best_param = 0
  
  for (index in 1:length(param)) {
    RSS = DS(data, name, param[index])[1]
    if(RSS <= min(result)){
      best_param = param[index]
    }
    result[index] = RSS
  }
  plot(result)
  title("training result")
  return(best_param)
}

original_BDS <- function(train_data, test_data, names, params, eta, B){
  clfs = data.frame(matrix(vector(), 0, 4, dimnames=list(c(), c("RSS_total", "threshold", "lessthan_value", "biggerthan_value"))), stringsAsFactors=F)
  
  for(i in 1:B){
   # randomly choose the target col to split
   random_index = sample.int(length(names),1)
   name = names[random_index]
   param = params[random_index]
   list[RSS_total, threshold, lessthan_value, biggerthan_value] = DS(train_data, name, param)
   clfs[i, ] <- c(RSS_total, threshold, lessthan_value, biggerthan_value)
  }
  # print("Your trained model")
  # print(clfs)
  
  MSE = 0
  for(index in 1:dim(test_data)[1]){
    y_hat = 0
    for(i in 1:B){
      y_hat = y_hat + eta*prediction(test_data[index,], clfs[i,]$threshold, clfs[i,]$lessthan_value, clfs[i,]$biggerthan_value)
    }
    MSE = MSE + (test_data[index, ]$medv - y_hat)**2
  }
  return(MSE/dim(test_data)[1])
}


BDS <- function(train_data, test_data, names, params, eta, B){
  clfs = data.frame(matrix(vector(), 0, 4, dimnames=list(c(), c("RSS_total", "threshold", "lessthan_value", "biggerthan_value"))), stringsAsFactors=F)
  residuals = c(10000)
  
  for(i in 1:B){
    # stopping condition
    if(ave(residuals)>0.1){
      for(index in 1:dim(train_data)[1]){
        residuals[index] = train_data[index,]$medv
        # randomly choose the target col to split
        random_index = sample.int(length(names),1)
        name = names[random_index]
        param = params[random_index]
        list[RSS_total, threshold, lessthan_value, biggerthan_value] = DS(train_data, name, param)
        clfs[i, ] <- c(RSS_total, threshold, lessthan_value, biggerthan_value)
        residuals[index] = residuals[index] - residuals[index]*eta*prediction(train_data[index,], clfs[i,]$threshold, clfs[i,]$lessthan_value, clfs[i,]$biggerthan_value)
      }
    }else{break}
  }
  print(clfs)
  break
  
  for(index in 1:dim(test_data)[1]){
    residual = test_data[index,]$medv
    for(i in 1:dim(clfs)[1]){
      # stopping condition to go overfitting
      if(residual>0.1){
        residual = residual - residual*eta*prediction(test_data[index,], clfs[i,]$threshold, clfs[i,]$lessthan_value, clfs[i,]$biggerthan_value)
      } else{break}
    }
  }
  return(clfs)
}

prediction <- function(new_data, threshold, lessthan_value, biggerthan_value){
  if(new_data < threshold){
    return(lessthan_value)
  } else {
    return(biggerthan_value)
  }
}

# Set threshold
s_lstat = seq(1.8,37.9,0.1)
s_rm = seq(3.6,8.7,0.1)

# Set seed for randomness
set.seed(925)

# split the data into two equal parts, train and test
train_length = length(medv)/2
train_indices = sample(1:length(medv), train_length)
train = Boston[train_indices,]
test  = Boston[-train_indices,]

# remove the unnecessary columns
keeps <- c("lstat", "rm", "medv")
train <- train[keeps]
test  <- test[keeps]

# training DS
best_s_lstat = training(train, "lstat", s_lstat)
best_s_rm = training(train, "rm", s_rm)

# Q1. Train your DS implementation on the training set. Find the MSE on the test set. Include it in your report.
test_MSE_lstat = DS(test, "lstat", best_s_lstat)[1]/dim(test)[1]
test_MSE_rm = DS(test, "rm", best_s_rm)[1]/dim(test)[1]
print(test_MSE_lstat)
print(test_MSE_rm)

# Q2. Train your BDS implementation on the training set for learning rate eta = 0.01 and B = 1000 trees. Find the MSE on the test set. Include it in your report.
tic()
print(original_BDS(train, test, c("lstat", "rm"), c(best_s_lstat,best_s_rm), 0.01, 1000))
exectime <- toc()
exectime <- exectime$toc - exectime$tic

# Q3. Plot the test MSE for a fixed value of eta as a function of B includes [1, B0] (the number of trees) for as large B0 as possible. 
# Do you observe overfitting? Include the plot and answer in your report.
test_mse = c()
run_time_measure = c()
Bs = c(seq(1,1500,100))
for (i in 1:length(Bs)) {
  tic()
  test_mse[i] = original_BDS(train, test, c("lstat", "rm"), c(best_s_lstat,best_s_rm), 0.01, Bs[i])
  exectime <- toc()
  run_time_measure[i] <- exectime$toc - exectime$tic
}

plot(test_mse)
title("Test MSE for BDS")
plot(run_time_measure)
title("run time for BDS")
