## Marking ID

**2290**

## Task Description

1. Implement DS(Decision Stumps) and BDS(Boosted Decision Stumps).
2. Apply DS/BDS to Boston dataset to predict `medv` given `lstat` and `rm`. **No need to Normalise them!!
3. Split the data randomly into two *equal* parts as training and test. Set your birthday(MMDD formatted) as the seed for the randomness.

## Questions
  1. Train your DS implementation on the training set. Find the MSE on the test set. Include it in your report.
  	* Test MSE for `lstat`: **192.9352**, Best param for `lstat`: **2.4**
  	* Test MSE for `rm`: **348.7673**, Best param for `rm`: **6.5**
  2. Train your BDS implementation on the training set for learning rate eta = 0.01 and B = 1000 trees. Find the MSE on the test set. Include it in your report.

     * Test MSE for BDS: **5591.201**

  3. Plot the test MSE for a fixed value of eta as a function of B includes [1, B0] (the number of trees) for as large B0 as possible. Do you observe overfitting? Include the plot and answer in your report.

     Answer: 

     ​	As the picture below indicates, we can see that the Test MSE exponentially increase as the complexity of the model increase. 

     ![test_mse](C:\Users\kosak\Documents\R\rhul_data_analysis\Assignment2\test_mse.png)

     Also, the run time linearly increased as well.

     ![run_time](C:\Users\kosak\Documents\R\rhul_data_analysis\Assignment2\run_time.png)