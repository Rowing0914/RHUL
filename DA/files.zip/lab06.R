# ======== Practise ========
rec <- function(x) (abs(x) < 1)*0.5
tri <- function(x) (abs(x) < 1) * (1 - abs(x))
gauss <- function(x) 1/sqrt(2*pi)*exp(-(x^2)/2)
x <- seq(from=-3, to=3, by=0.001)
plot(x, rec(x), type="l", ylim=c(0,1), lty=1, ylab=expression(K(x)))
lines(x, tri(x), lty=2)
lines(x, gauss(x), lty=3)
legend(-3, 0.8, legend=c("Rectangular", "Triangular", "Gaussian"), lty=1:3, title="kernel functions", bty="n")
x <- c(0, 1, 1.1, 1.5, 1.9, 2.8, 2.9, 3.5)
n <- length(x)
xgrid <- seq(from=min(x)-1, to=max(x)+1, by=0.01)
h <- 0.4
bumps <- sapply(x, function(a) gauss((xgrid-a)/h)/(n*h))
plot(xgrid, rowSums(bumps), ylab=expression(hat(f)(x)), type="l", xlab="x", lwd=2)
rug(x, lwd=2)
out <- apply(bumps, 2, function(b) lines(xgrid, b))
set.seed(2)
x <- matrix(rnorm(50*2), ncol=2)
x[1:25,1] <- x[1:25,1]+3
x[1:25,2] <- x[1:25,2]-4
km.out <- kmeans(x,2, nstart = 20)
km.out$cluster
plot(x, col=(km.out$cluster+1), main="K-Means Clustering Results with k=2", xlab="", ylab="", pch=20, cex=2)
set.seed(4)
km.out <- kmeans(x, 3, nstart = 20)
km.out
set.seed(3)
km.out <- kmeans(x, 3, nstart = 1)
km.out$tot.withinss
km.out <- kmeans(x, 3, nstart = 20)
km.out$tot.withinss
hc.complete <- hclust(dist(x), method="complete")
hc.average <- hclust(dist(x), method="average")
hc.single <- hclust(dist(x), method="single")
par(mfrow=c(1,3))
plot(hc.complete, main = "Complete Linkage", xlab="", sub="", cex=.9)
plot(hc.average, main = "Average Linkage", xlab="", sub="", cex=.9)
plot(hc.single, main = "Single Linkage", xlab="", sub="", cex=.9)
cutree(hc.complete, 2)
cutree(hc.average, 2)
cutree(hc.single, 2)
xsc <- scale(x, center=FALSE, scale=TRUE)
plot(hclust(dist(xsc), method="complete"), main="Hierarchical Clustering with Scaled Observatoins")
xsc = scale(x)
plot(hclust(dist(xsc), method="complete"), main="Hierarchical Clustering with Scaled Observations")

# ===== Exercises =====
# 1. We used h = 0.4 in kernel density estimation in Section 1. Now try different values for h and describe your results.
h <- 0.5
bumps <- sapply(x, function(a) gauss((xgrid-a)/h)/(n*h))
plot(xgrid, rowSums(bumps), ylab=expression(hat(f)(x)), type="l", xlab="x", lwd=2)
rug(x, lwd=2)
out <- apply(bumps, 2, function(b) lines(xgrid, b))

h <- 1
bumps <- sapply(x, function(a) gauss((xgrid-a)/h)/(n*h))
plot(xgrid, rowSums(bumps), ylab=expression(hat(f)(x)), type="l", xlab="x", lwd=2)
rug(x, lwd=2)
out <- apply(bumps, 2, function(b) lines(xgrid, b))

h <- 0.05
bumps <- sapply(x, function(a) gauss((xgrid-a)/h)/(n*h))
plot(xgrid, rowSums(bumps), ylab=expression(hat(f)(x)), type="l", xlab="x", lwd=2)
rug(x, lwd=2)
out <- apply(bumps, 2, function(b) lines(xgrid, b))

# 2.(a)
x <- matrix(rnorm(60*2), ncol=2)
x[1:20,1] <- x[1:20,1]+1
x[1:20,2] <- x[1:20,2]-1
x[20:40,1] <- x[20:40,1]+2
x[20:40,2] <- x[20:40,2]-2
x[40:60,1] <- x[40:60,1]+3
x[40:60,2] <- x[40:60,2]-3

# 2.(b)
km.out <- kmeans(x,3, nstart = 20)
km.out$cluster
plot(x, col=(km.out$cluster+1), main="K-Means Clustering Results with k=3", xlab="", ylab="", pch=20, cex=2)

# 2.(c)
km.out <- kmeans(x,2, nstart = 20)
km.out$cluster
plot(x, col=(km.out$cluster+1), main="K-Means Clustering Results with k=2", xlab="", ylab="", pch=20, cex=2)

# 2.(d)
km.out <- kmeans(x,4, nstart = 20)
km.out$cluster
plot(x, col=(km.out$cluster+1), main="K-Means Clustering Results with k=2", xlab="", ylab="", pch=20, cex=2)

# 3.(a)
hc.complete <- hclust(dist(USArrests), method="complete")
plot(hc.complete, main = "Complete Linkage", xlab="", sub="", cex=.9)

# 3.(b)
cutree(hc.complete, 3)

# 3.(c)
x = USArrests
xsc <- scale(x, center=FALSE, scale=TRUE)
hc.complete <- hclust(dist(USArrests), method="complete")
plot(hc.complete, main = "Complete Linkage", xlab="", sub="", cex=.9)

hc.complete_scaled <- hclust(dist(xsc), method="complete")
plot(hc.complete_scaled, main = "Complete Linkage", xlab="", sub="", cex=.9)

# 3.(d)
table(cutree(hc.complete, 3), cutree(hc.complete_scaled, 3))
