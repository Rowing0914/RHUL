LoadLibraries <- function(){
  library(ISLR)
  library(MASS)
  library(class)
  print('the libraries have been loaded!')
}
LoadLibraries()

curve(x*sin(x^2), -3, 3)

x <- seq(-3, 3, 0.01)
y <- x*sin(x^2)
plot(x, y, type="l")

cube <- function(x){
  return (x^3)
}
cube(3)

norm <- function(x, y=0){
  squared.norm <- x^2+y^2
  return (sqrt(squared.norm))
}

norm(3,4)
norm(3)

for (i in 1:4) {
  print(i)
}

dim(Caravan)
attach(Caravan)
summary(Purchase)
print(348/5822)

standardized.X <- scale(Caravan[, -86])
var(Caravan[,1])
var(Caravan[,2])
var(standardized.X[,1])
var(standardized.X[,2])

test <- 1:1000
train.X <- standardized.X[-test,]
test.X <- standardized.X[test,]
train.Y <- Purchase[-test]
test.Y <- Purchase[test]
set.seed(1)

knn.pred <- knn(train.X, test.X, train.Y, k=1)
mean(test.Y != knn.pred)
mean(test.Y != "No")
table(knn.pred, test.Y)
9/(68+9)

knn.pred <- knn(train.X, test.X, train.Y, k=3)
table(knn.pred, test.Y)
5/26

knn.pred <- knn(train.X, test.X, train.Y, k=5)
table(knn.pred, test.Y)
4/15

glm.fit <- glm(Purchase~., data=Caravan, family=binomial, subset=-test)
glm.probs <- predict(glm.fit, Caravan[test,], type="response")
glm.pred <- rep("No", 1000)
glm.pred[glm.probs>.5] <- "Yes"
table(glm.pred, test.Y)

glm.pred <- rep("No", 1000)
glm.pred[glm.probs>.25] <- "Yes"
table(glm.pred, test.Y)
11/(11+22)




# =========== Exercise ===========
# 1. Write a function, Power(), that prints out the result of raising 2 to the
# 3rd power. In other words, your function should compute 2^3 and print 6
# out the results. Hint: Recall that x^a raises x to the power a. Use the
# print() function to output the result.

Power <- function(){
  print(2^3)
}
Power()

# 2. Create a new function, Power2(), that allows you to pass any two numbers,
# x and a, and prints out the value of x^a. You can do this by beginning
# your function with the line
# > Power2 <- function(x,a){
# You should be able to call your function by entering, for instance
# > Power2(3,8)
# on the command line. This should output the value of 38
# , namely, 6561.
Power2 <- function(x,a){
  print(x^a)
}
Power2(3,8)

# 3. Using the Power2() function that you just wrote, compute 10^3 , 8^17, and 131^3
Power2(10, 3)
Power2(8, 17)
Power2(131, 3)

# 4. Now create a new function, Power3(), that actually returns the result x^a
# as an R object, rather than simply printing it to the screen. That is, if
# you store the value x^a in an object called result within your function,
# then you can simply return() this result using the following line:

Power3 <- function(x,a){
  return(x^a)
}

a = Power3(2,3)
a

# 5. Now using the Power3() function, create a plot of f(x) = x^2
# The x-axis should display a range of integers from 1 to 10, and the y-axis should
# display x 2 . Label the axes appropriately, and use an appropriate title for
# the figure. Consider displaying either the x-axis, the y-axis, or both on
# the log-scale. You can do this by using log="x", log="y", or log="xy"
# as arguments to the plot() function.

# answer 1
curve(Power3(x,2), 1,10)
axis(side = 1, at=seq(1,10))
title("f(x)=x^2")

# answer 2
sample = 1:10
result = c()

for (i in sample)
  result[i] = Power3(i, 2)

print(result)
plot(sample, result, xlim=c(1,10), main="f(x)=x^2")
axis(side = 1, at=seq(1,10))

# 6. Create a function, PlotPower(), that allows you to create a plot of x
# against x^a for a fixed a and for a range of values of x. For instance, if you call

PlotPower <- function(x, a){
  curve(Power3(x,a), 1, max(x))
  axis(side = 1, at=seq(1,max(x)))
}

PlotPower(1:12, 3)

# 7. Write your own function sum2() that given input n finds the sum 12 + 2 2 + · · · + n 2.
# An example of its use:

sum2 <- function(n){
  return(sum((function(x) Power3(x,2)) (1:n)))
}
sum2(3)

# 8. Write a function sum3() that given input n finds the sum 13+23+· · ·+n
# Store this function in a file. Run this file as a script. Check that it works; for example:

sum3 <- function(n){
  return(sum((function(x) Power3(x,3)) (1:n)))
}
sum3(3)
