calc_distance <- function(data){
  data_length = dim(data)[1]
  result = matrix(ncol=data_length, nrow=data_length)
  for (i in 1:data_length) {
  	for (n in 1:data_length) {
    	if(i < n){
    		result[i,n] = 0
    	} else{	
    		result[i,n] = sqrt(sum(data[i,] - data[n,])**2)
    	}
    }
  }
  return(result)
}

findN <- function(x, arg="all", n=2){
	dummy = as.vector(x)
  len = length(dummy)
  if(n > len){N = length(dummy)}
  result = sort(dummy)
  if(arg == "min"){
  	return(which(x == result[result>0][n], TRUE))
  } else if(arg == "max"){
  	# take a sequence of 0 into account by adding sum(result==0) to the index
  	return(which(x == result[result>0][len-n+1-sum(result==0)], TRUE))
  } else if(arg == "all"){
  	# debug purpose
  	sprintf("%1.f th Min: %f, %1.f th Max: %f", n, result[n], len-n+1, result[len-n+1])
  }
}

clustering <- function(row_original_data, index_matrix){
	col = row_original_data-1
	clusters = matrix(rep(0, len=row_original_data*col), nrow=row_original_data, ncol=col)
	for (i in 1:col) {
		if(i != 1){
			# check previous cluster
			c1 = max(clusters[index_matrix[i,][1],])
			c2 = max(clusters[index_matrix[i,][2],])
			print(sprintf("iteration: %1.f, Merge c1: %1.f and c2: %1.f", i, c1, c2))
			if((c1 != 0) & (c2 != 0)){
				index_1 = which(clusters == c1, TRUE)
				index_2 = which(clusters == c2, TRUE)
				for (n in 1:dim(index_1)[1]) {
					clusters[index_1[n,1], i] = i
				}
				for (n in 1:dim(index_2)[1]) {
					clusters[index_2[n,1], i] = i
				}
			} else if((c1 == 0) & (c2 != 0)){
				clusters[which(clusters == c2, TRUE)[,1],i] = i
			} else if((c1 != 0) & (c2 == 0)){
				clusters[which(clusters == c1, TRUE)[,1],i] = i
			}
		}
		clusters[index_matrix[i,][1], i] = i
		clusters[index_matrix[i,][2], i] = i
	}
	clusters[, i] = i
	return(clusters)
}

linkage <- function(original, data, type){
	index_matrix = matrix(rep(0, len=sum(data!=0)), ncol=2)
	if (type == "single"){
		print("single")
		for (i in 1:sum(data!=0)/2) {
			index_matrix[i,1] = findN(data, "min", n=i)[1]
			index_matrix[i,2] = findN(data, "min", n=i)[2]
		}
		print("==== Clustering Start ====")
		clusters = clustering(dim(original)[1], index_matrix)
	} else if(type == "complete"){
		print("complete")
		for (i in 1:sum(data!=0)/2) {
			index_matrix[i,1] = findN(data, "max", n=i)[1]
			index_matrix[i,2] = findN(data, "max", n=i)[2]
		}
		print("==== Clustering Start ====")
		clusters = clustering(dim(original)[1], index_matrix)
	} else if(type == "average"){
		print("average")
		for (i in 1:sum(data!=0)/2) {
			index_matrix[i,1] = findN(data, "min", n=i)[1]
			index_matrix[i,2] = findN(data, "min", n=i)[2]
		}
		print("==== Clustering Start ====")
		clusters = clustering(dim(original)[1], index_matrix)
	} else if(type == "centroid"){
		print("centroid")
	}
	return(clusters)
}

cut_tree <- function(mat, num_clusters){
	len = dim(mat)[1]
	for (i in num_clusters:len-1) {
		result_mat = apply(mat[,1:i], 1, which.max)
		temp = unique(result_mat)
		if(length(temp)[1] >= num_clusters){
			return(result_mat)
		}
	}
}

save_plot <- function(X, result, filename){
	png(filename=filename)
	plot(X, col=(result))
	dev.off()
}

setwd("C:/Users/kosak/Desktop/RHUL/rhul_da/Assignment3/")

# 2. Import dataset [64 x 6830] and preprocess it
X = read.table('nci.data.txt')
X = t(X)
# preprocess data using scale()
X = scale(X, center=FALSE, scale=TRUE)
y = read.table('label.txt')
elem = dim(unique(y))[1]
save_plot(X, cut_tree(linkage(X, calc_distance(X), "single"), elem), "./images/single.png")
save_plot(X, cut_tree(linkage(X, calc_distance(X), "complete"), elem), "./images/complete.png")
save_plot(X, cut_tree(linkage(X, calc_distance(X), "average"), elem), "./images/average.png")

# 4. Applying K-Means
km.out <- kmeans(X, 14)
km.out
png(filename="./images/k_14.png")
plot(X, col=(km.out$cluster+1), main="K-Means Clustering Results with k=14", xlab="", ylab="", pch=20, cex=2)
dev.off()