import numpy as np
import matplotlib.pyplot as plt
import itertools


def calculate_J(x,y,m,c):
    """
    x, y are ndarrays of the same length
    m and c are floating point numbers giving gradient and intercept of a line
    """
    yhat  = m * x + c
    errs = (yhat - y)**2
    J = np.mean( errs )
    return J


def J_gradient(x, y, m, c):
    """
    x, y are ndarrays of the same length
    m and c are floating point numbers giving gradient and intercept of a line

    Returns the gradient J with respect to
    """
    yhat = m * x + c
    c_grads = 2 * (yhat - y)
    m_grads = 2 * (yhat - y) * x
    # now take the means of these, since J is the mean of the square error
    c_grad = np.mean(c_grads)
    m_grad = np.mean(m_grads)
    return (m_grad, c_grad)

def train(n_iterations=200, learning_rate=0.034):
    m = 0.0
    c = 0.0

    m_path = [m]
    c_path = [c]

    for n in range(1,n_iterations):
        m_grad, c_grad = J_gradient(x_data, y_data, m, c )
        m = m - learning_rate * m_grad
        c = c - learning_rate * c_grad
        m_path.append(m)
        c_path.append(c)
    return m_path, c_path

def visualise(m_path, c_path):
    plt.imshow(1. / J_grid.transpose(), origin='lower',extent=[0,1,0,2])
    plt.colorbar()
    plt.plot(m_path,c_path,'r')
    plt.plot(m_path,c_path,'r.')

def train_1(n_iterations=200, learning_rate=0.034):
    m = 0.0
    c = 0.0

    m_path = [m]
    c_path = [c]
    m_path_f = m
    c_path_f = c

    for cnt in itertools.count(start=1, step=2):
        for n in range(1,n_iterations):
            m_grad, c_grad = J_gradient(x_data, y_data, m, c )
            m = m - learning_rate*cnt * m_grad
            c = c - learning_rate*cnt * c_grad
            if (m_path[-1] < m) and (c_path[-1] < c):
                m_path.append(m)
                c_path.append(c)
            else:
                break

        if (m_path_f < m_path[-1]) and (c_path_f < c_path[-1]):
            m_path_f = m_path[-1]
            c_path_f = c_path[-1]
        else:
            print('The highest value of the learning rate which holds the convergence is: {0}'.format(learning_rate*cnt))
            break
    return learning_rate*cnt


# def train_2(n_iterations=200, learning_rate=0.034):
#     m = 0.0
#     c = 0.0
#
#     m_path = [m]
#     c_path = [c]
#     log_learning = dict()
#     errors = list()
#
#     for n in range(1,n_iterations):
#         errors.append(calculate_J(x_data, y_data, m, c))
#
#         m_grad, c_grad = J_gradient(x_data, y_data, m, c )
#         m = m - learning_rate * m_grad
#         c = c - learning_rate * c_grad
#         if (m_path[-1] < m) and (c_path[-1] < c):
#             m_path.append(m)
#             c_path.append(c)
#         else:
#             break
#     visualise(m_path, c_path)
#     # return learning_rate*cnt


def train_2(n_iterations=200, learning_rate=0.034):
    m = 0.0
    c = 0.0

    m_path = [m]
    c_path = [c]
    log_learning = dict()
    errors = list()

    for cnt in itertools.count(start=1, step=2):
        for n in range(1, n_iterations):
            errors.append(calculate_J(x_data, y_data, m, c))

            m_grad, c_grad = J_gradient(x_data, y_data, m, c)
            m = m - learning_rate * cnt * m_grad
            c = c - learning_rate * cnt * c_grad
            m_path.append(m)
            c_path.append(c)

        log_learning['lr'] = learning_rate * cnt
        log_learning['error'] = errors

        errors = list()
        if cnt >= 10:
            break
            return log_learning


def multi_plot(log_learning):
    for i in range(len(log_learning)):
        plt.plot(log_learning['errors'], label=log_learning['lr'])
    plt.legend()
    plt.show()

def train_4(n_iterations=200, learning_rate=0.034, momentum=1.0):
    m = 0.0
    c = 0.0

    m_path = [m]
    c_path = [c]
    m_change, c_change = 1,1

    for n in range(1,n_iterations):
        m_grad, c_grad = J_gradient(x_data, y_data, m, c )

        # update change
        m_change = momentum * m_change - learning_rate * m_grad
        c_change = momentum * c_change - learning_rate * c_grad


        # update m,c
        m += m_change
        c += c_change
        m_path.append(m)
        c_path.append(c)
    return m_path, c_path


if __name__ == '__main__':
    x_data = np.array([x for x in range(0, 10)])
    y_data = 1.1 + 0.6 * x_data + np.random.randn(x_data.size)
    # train_1()
    # train_4()
    log_learning = train_2()
    multi_plot(log_learning)